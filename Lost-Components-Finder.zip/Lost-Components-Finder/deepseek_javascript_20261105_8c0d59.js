// main.js

// Показываем интерфейс плагина
pixso.showUI(__html__, {
  width: 420,
  height: 600,
  title: "Поиск потерянных компонентов"
});

// Запускаем сканирование сразу после загрузки UI
pixso.ui.onmessage = async (msg) => {
  if (msg.type === "start-scan") {
    await scanAllPages();
  }
};

async function scanAllPages() {
  // Получаем все страницы документа
  // pixso.root — корневой узел документа, его children — страницы
  const pages = pixso.root.children.filter((node) => node.type === "PAGE");

  if (!pages.length) {
    pixso.ui.postMessage({
      type: "error",
      message: "В файле не найдено ни одной страницы."
    });
    return;
  }

  const totalPages = pages.length;
  const lostInstances = [];

  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];

    // Отправляем прогресс в UI: текущая страница, номер, всего страниц
    pixso.ui.postMessage({
      type: "progress",
      current: i + 1,
      total: totalPages,
      pageName: page.name
    });

    // Небольшая задержка, чтобы UI успел отрисовать прогресс
    await new Promise((resolve) => setTimeout(resolve, 10));

    try {
      // findAllAsync — актуальный метод для Pixso 2.0+
      // Он возвращает все узлы на странице, после чего фильтруем
      const allNodes = await page.findAllAsync();

      for (const node of allNodes) {
        // Проверяем ТОЛЬКО экземпляры (обычные объекты игнорируются)
        if (node.type !== "INSTANCE") continue;

        // Если mainComponent === null, значит главный компонент удалён
        if (node.mainComponent === null) {
          lostInstances.push({
            pageName: page.name,
            pageId: page.id,
            instanceName: node.name,
            instanceId: node.id
          });
        }
      }
    } catch (err) {
      // Если на странице произошла ошибка, сообщаем в UI, но продолжаем
      pixso.ui.postMessage({
        type: "warning",
        message: `Ошибка на странице «${page.name}»: ${err.message}`
      });
    }
  }

  // Отправляем итоговый результат в UI
  pixso.ui.postMessage({
    type: "result",
    data: lostInstances,
    totalPages: totalPages
  });
}