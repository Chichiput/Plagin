pixso.showUI(__html__, { width: 480, height: 680 });

const varNameCache = new Map();

const STATE_SUFFIXES = new Set([
  'default', 'hover', 'active', 'focus', 'focused', 'disabled', 'pressed', 'opened',
  'checked', 'checkedhover', 'hasvalue',
  'selected', 'selecteddefault', 'selectedhover', 'selectedactive', 'selecteddisabled', 'selectedfocus',
  'activedefault', 'activehover', 'activepressed', 'activedisabled',
  'defaulthover', 'defaultfocus', 'defaultlight', 'hoverlight', 'selectedlight',
  'lightselecteddefault', 'lightselectedhover', 'lightselectedactive',
  'lightselectedfocus', 'lightselecteddisabled',
  'darkselecteddefault', 'darkselectedhover', 'darkselectedactive',
  'darkselectedfocus', 'darkselecteddisabled'
]);

function getMainName(name) {
  if (!name) return name;
  let base = name.split(',')[0].trim();
  const sep = base.includes('/') ? '/' : '.';
  const parts = base.split(/[./]/);
  while (parts.length > 1 && STATE_SUFFIXES.has(parts[parts.length - 1].toLowerCase())) {
    parts.pop();
  }
  return parts.join(sep);
}

async function buildLocalVariablesMap() {
  const localVars = await pixso.variables.getLocalVariablesAsync('COLOR');
  const byName = new Map();
  localVars.forEach(v => byName.set(v.name, v));
  return byName;
}

async function buildLibraryVariableNameMap() {
  const nameMap = new Map();
  try {
    const collections = await pixso.teamLibrary.getAvailableLibraryVariableCollectionsAsync();
    for (const col of collections) {
      const libVars = await pixso.teamLibrary.getVariablesInLibraryCollectionAsync(col.key);
      for (const lv of libVars) {
        if (lv.id && lv.name) nameMap.set(lv.id, lv.name);
      }
    }
  } catch (e) {
    console.warn('teamLibrary недоступен:', e);
  }
  return nameMap;
}

async function resolveVariableName(varId, libraryNameMap) {
  if (varNameCache.has(varId)) return varNameCache.get(varId);
  const direct = await pixso.variables.getVariableByIdAsync(varId);
  let name = direct?.name || null;
  if (!name && libraryNameMap.has(varId)) name = libraryNameMap.get(varId);
  varNameCache.set(varId, name);
  return name;
}

async function collectNodeTokenNames(node, libraryNameMap, outSet) {
  if (node.fills && node.fills.length > 0) {
    for (const paint of node.fills) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const name = await resolveVariableName(paint.boundVariables.color.id, libraryNameMap);
        if (name) outSet.add(name);
      }
    }
  }
  if (node.strokes && node.strokes.length > 0) {
    for (const paint of node.strokes) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const name = await resolveVariableName(paint.boundVariables.color.id, libraryNameMap);
        if (name) outSet.add(name);
      }
    }
  }
  if ('children' in node) {
    for (const child of node.children) {
      await collectNodeTokenNames(child, libraryNameMap, outSet);
    }
  }
}

// Сканирует ОДНУ страницу и наполняет usage
async function scanPageTokens(page, libraryNameMap, usage, onProgress) {
  const allNodes = await page.findAllAsync(
    n => n.type === 'COMPONENT' || n.type === 'COMPONENT_SET'
  );

  const components = allNodes.filter(c => {
    if (c.type === 'COMPONENT_SET') return true;
    return c.parent?.type !== 'COMPONENT_SET';
  });

  const total = components.length;

  for (let i = 0; i < total; i++) {
    const comp = components[i];
    await new Promise(r => setTimeout(r, 0));

    if (onProgress) onProgress(i + 1, total, comp.name);

    const compMain = getMainName(comp.name);
    const rawTokens = new Set();

    if (comp.type === 'COMPONENT_SET') {
      for (const variant of comp.children) {
        if (variant.type === 'COMPONENT') {
          await collectNodeTokenNames(variant, libraryNameMap, rawTokens);
        }
      }
    } else {
      await collectNodeTokenNames(comp, libraryNameMap, rawTokens);
    }

    for (const rawToken of rawTokens) {
      const mainToken = getMainName(rawToken);
      if (!usage.has(mainToken)) usage.set(mainToken, new Set());
      usage.get(mainToken).add(compMain);
    }
  }

  return total;
}

function buildResult(usage, pageLabel, totalComponents, localVarsByName) {
  const tokens = [];
  for (const [name, compSet] of usage.entries()) {
    tokens.push({
      name,
      isLocal: localVarsByName.has(name) ||
               Array.from(localVarsByName.keys()).some(k => getMainName(k) === name),
      components: Array.from(compSet).sort()
    });
  }
  tokens.sort((a, b) => {
    if (a.isLocal !== b.isLocal) return a.isLocal ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  return {
    tokens,
    pageName: pageLabel,
    totalComponents,
    totalTokens: tokens.length,
    localTokensUsed: tokens.filter(t => t.isLocal).length,
    externalTokensUsed: tokens.filter(t => !t.isLocal).length
  };
}

// ---------- Скан текущей страницы ----------
async function scanCurrentPage() {
  const page = pixso.currentPage;
  if (!page) return { error: 'Не удалось получить текущую страницу.' };

  const localVarsByName = await buildLocalVariablesMap();
  const libraryNameMap = await buildLibraryVariableNameMap();
  const usage = new Map();

  pixso.ui.postMessage({
    type: 'page-start',
    pageIndex: 1,
    totalPages: 1,
    pageName: page.name
  });

  const total = await scanPageTokens(page, libraryNameMap, usage, (curr, tot, name) => {
    pixso.ui.postMessage({
      type: 'progress',
      pageIndex: 1,
      totalPages: 1,
      pageName: page.name,
      current: curr,
      total: tot,
      name,
      overallPercent: tot > 0 ? Math.round((curr / tot) * 100) : 0
    });
  });

  if (total === 0) {
    return { error: `На странице «${page.name}» не найдено компонентов.` };
  }

  return {
    result: buildResult(usage, `страница «${page.name}»`, total, localVarsByName),
    scope: 'page'
  };
}

// ---------- Скан всего файла (постранично, последовательно) ----------
async function scanAllPages() {
  const pages = pixso.root.children;
  const totalPages = pages.length;
  if (totalPages === 0) return { error: 'В файле нет страниц.' };

  const localVarsByName = await buildLocalVariablesMap();
  const libraryNameMap = await buildLibraryVariableNameMap();
  const usage = new Map();

  let totalComponentsOverall = 0;

  for (let p = 0; p < pages.length; p++) {
    const page = pages[p];

    pixso.ui.postMessage({
      type: 'page-start',
      pageIndex: p + 1,
      totalPages,
      pageName: page.name
    });

    const pageTotal = await scanPageTokens(page, libraryNameMap, usage, (curr, tot, name) => {
      // Общий процент = (пройденные страницы + доля текущей) / всего страниц
      const overall = Math.round(
        ((p + (tot > 0 ? curr / tot : 1)) / totalPages) * 100
      );
      pixso.ui.postMessage({
        type: 'progress',
        pageIndex: p + 1,
        totalPages,
        pageName: page.name,
        current: curr,
        total: tot,
        name,
        overallPercent: overall
      });
    });

    totalComponentsOverall += pageTotal;
  }

  if (totalComponentsOverall === 0) {
    return { error: 'В файле не найдено компонентов ни на одной странице.' };
  }

  return {
    result: buildResult(usage, `весь файл (${totalPages} стр.)`, totalComponentsOverall, localVarsByName),
    scope: 'file'
  };
}

pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'load-tokens') {
    const localVarsByName = await buildLocalVariablesMap();
    pixso.ui.postMessage({ type: 'tokens-count', count: localVarsByName.size });
  }

  if (msg.type === 'scan-current-page' || msg.type === 'scan-all-pages') {
    try {
      varNameCache.clear();
      const out = msg.type === 'scan-current-page'
        ? await scanCurrentPage()
        : await scanAllPages();

      if (out.error) {
        pixso.ui.postMessage({ type: 'error', message: out.error });
      } else {
        pixso.ui.postMessage({
          type: 'scan-result',
          ...out.result,
          scope: out.scope
        });
      }
    } catch (e) {
      pixso.ui.postMessage({ type: 'error', message: e.message });
    }
  }
};