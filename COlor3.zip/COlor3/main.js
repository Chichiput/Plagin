// main.js

pixso.showUI(__html__, { width: 440, height: 560 });

let isSearching = false;

// === НАСТРОЙКИ ПОИСКА ===
const TARGET_HEX = '#1f1f22';
const TARGET_OPACITY = 0.55;
const COLOR_TOLERANCE = 0.01;
// =========================

const targetRgb = hexToRgb01(TARGET_HEX);

pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'start-search') {
    if (isSearching) return;
    isSearching = true;

    try {
      await findAllPagesColorUsage();
    } catch (err) {
      pixso.ui.postMessage({ type: 'error', message: err.message });
    } finally {
      isSearching = false;
    }
  }

  if (msg.type === 'navigate-to-node') {
    // msg.nodeId — узел, msg.pageId — страница, на которой он находится
    const node = await pixso.getNodeByIdAsync(msg.nodeId);
    if (!node) return;

    // Если узел на другой странице — сначала переключаемся на неё
    const currentPage = pixso.currentPage;
    if (currentPage && currentPage.id !== msg.pageId) {
      const page = await pixso.getNodeByIdAsync(msg.pageId);
      if (page && page.type === 'PAGE') {
        // В Pixso для переключения страницы используется setCurrentPageAsync
        // (в некоторых версиях — hostApi.setCurrentPage)
        if (typeof pixso.setCurrentPageAsync === 'function') {
          await pixso.setCurrentPageAsync(page.id);
        } else if (pixso.setCurrentPage) {
          await pixso.setCurrentPage(page.id);
        }
      }
    }

    pixso.viewport.scrollAndZoomIntoView([node]);
    pixso.currentPage.selection = [node];
  }
};

async function findAllPagesColorUsage() {
  // Получаем корневой узел документа.
  // В Pixso это pixso.root (DocumentNode), у которого children — PageNode[].
  // Альтернативно можно использовать pixso.currentPage.parent.
  let root = pixso.root;
  if (!root) {
    root = pixso.currentPage ? pixso.currentPage.parent : null;
  }
  if (!root) {
    pixso.ui.postMessage({ type: 'error', message: 'Не удалось получить документ.' });
    return;
  }

  const pages = (root.children || []).filter((n) => n.type === 'PAGE');
  if (pages.length === 0) {
    pixso.ui.postMessage({ type: 'error', message: 'В файле нет страниц.' });
    return;
  }

  const totalPages = pages.length;
  const results = []; // { pageId, pageName, componentId, componentName, nodeId, nodeName, sourceType }

  pixso.ui.postMessage({
    type: 'progress',
    current: 0,
    total: totalPages,
    label: 'Подготовка страниц…'
  });

  for (let p = 0; p < pages.length; p++) {
    const page = pages[p];
    const pageLabel = page.name || `Page ${page.id}`;

    pixso.ui.postMessage({
      type: 'progress',
      current: p,
      total: totalPages,
      label: `Страница ${p + 1} из ${totalPages}: ${pageLabel} — сбор компонентов…`
    });

    // Небольшая пауза, чтобы UI обновился
    await new Promise((r) => setTimeout(r, 0));

    const localComponents = page.findAllWithCriteria({
      types: ['COMPONENT', 'COMPONENT_SET']
    });

    const components = localComponents.filter(
      (n) => n.type === 'COMPONENT' || n.type === 'COMPONENT_SET'
    );

    for (let c = 0; c < components.length; c++) {
      const component = components[c];
      const componentLabel = component.name || `Component ${component.id}`;

      pixso.ui.postMessage({
        type: 'progress',
        current: p,
        total: totalPages,
        label: `Страница ${p + 1}/${totalPages} — ${pageLabel}: ${componentLabel} (${c + 1}/${components.length})`
      });

      await new Promise((r) => setTimeout(r, 0));

      await walkNode(component, component, page, results);
    }
  }

  pixso.ui.postMessage({
    type: 'progress',
    current: totalPages,
    total: totalPages,
    label: 'Готово'
  });

  pixso.ui.postMessage({ type: 'results', results });
}

async function walkNode(node, rootComponent, page, results) {
  // ----- FILLS -----
  const fillStyleId = node.fillStyleId;
  if (fillStyleId && fillStyleId !== pixso.mixed) {
    const style = await pixso.getStyleByIdAsync(fillStyleId);
    if (style && style.type === 'PAINT' && style.paints) {
      if (style.paints.some((p) => isTargetPaint(p))) {
        results.push({
          pageId: page.id,
          pageName: page.name || `Page ${page.id}`,
          componentId: rootComponent.id,
          componentName: rootComponent.name || `Component ${rootComponent.id}`,
          nodeId: node.id,
          nodeName: node.name || `Node ${node.id}`,
          sourceType: 'fill (style)'
        });
      }
    }
  } else if (node.fills && node.fills !== pixso.mixed) {
    if (Array.isArray(node.fills) && node.fills.some((p) => isTargetPaint(p))) {
      results.push({
        pageId: page.id,
        pageName: page.name || `Page ${page.id}`,
        componentId: rootComponent.id,
        componentName: rootComponent.name || `Component ${rootComponent.id}`,
        nodeId: node.id,
        nodeName: node.name || `Node ${node.id}`,
        sourceType: 'fill (direct)'
      });
    }
  }

  // ----- STROKES -----
  const strokeStyleId = node.strokeStyleId;
  if (strokeStyleId && strokeStyleId !== pixso.mixed) {
    const style = await pixso.getStyleByIdAsync(strokeStyleId);
    if (style && style.type === 'PAINT' && style.paints) {
      if (style.paints.some((p) => isTargetPaint(p))) {
        results.push({
          pageId: page.id,
          pageName: page.name || `Page ${page.id}`,
          componentId: rootComponent.id,
          componentName: rootComponent.name || `Component ${rootComponent.id}`,
          nodeId: node.id,
          nodeName: node.name || `Node ${node.id}`,
          sourceType: 'stroke (style)'
        });
      }
    }
  } else if (node.strokes && node.strokes !== pixso.mixed) {
    if (Array.isArray(node.strokes) && node.strokes.some((p) => isTargetPaint(p))) {
      results.push({
        pageId: page.id,
        pageName: page.name || `Page ${page.id}`,
        componentId: rootComponent.id,
        componentName: rootComponent.name || `Component ${rootComponent.id}`,
        nodeId: node.id,
        nodeName: node.name || `Node ${node.id}`,
        sourceType: 'stroke (direct)'
      });
    }
  }

  if (node.children && node.children.length > 0) {
    for (const child of node.children) {
      await walkNode(child, rootComponent, page, results);
    }
  }
}

function isTargetPaint(paint) {
  if (!paint || paint.type !== 'SOLID') return false;
  if (paint.visible === false) return false;

  const { color, opacity } = paint;
  if (!color) return false;

  const rMatch = Math.abs(color.r - targetRgb.r) <= COLOR_TOLERANCE;
  const gMatch = Math.abs(color.g - targetRgb.g) <= COLOR_TOLERANCE;
  const bMatch = Math.abs(color.b - targetRgb.b) <= COLOR_TOLERANCE;

  if (!(rMatch && gMatch && bMatch)) return false;

  const paintOpacity = opacity === undefined ? 1 : opacity;
  return Math.abs(paintOpacity - TARGET_OPACITY) <= 0.01;
}

function hexToRgb01(hex) {
  const cleaned = hex.replace('#', '');
  const bigint = parseInt(cleaned, 16);
  const r = ((bigint >> 16) & 255) / 255;
  const g = ((bigint >> 8) & 255) / 255;
  const b = (bigint & 255) / 255;
  return { r, g, b };
}