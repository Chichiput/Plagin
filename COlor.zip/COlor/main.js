// main.js

pixso.showUI(__html__, { width: 420, height: 540 });

let isSearching = false;

// === НАСТРОЙКИ ПОИСКА ===
const TARGET_HEX = '#1f1f22';                 // искомый цвет
const TARGET_OPACITY = 0.55;                  // 55% непрозрачности (если нужна прозрачность 55% → 0.45)
const COLOR_TOLERANCE = 0.01;                 // допуск при сравнении RGB (0–1)
// =========================

// Предварительно вычисляем целевые RGB из hex
const targetRgb = hexToRgb01(TARGET_HEX);

pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'start-search') {
    if (isSearching) return;
    isSearching = true;

    try {
      await findColorUsage();
    } catch (err) {
      pixso.ui.postMessage({ type: 'error', message: err.message });
    } finally {
      isSearching = false;
    }
  }

  if (msg.type === 'navigate-to-node') {
    const node = await pixso.getNodeByIdAsync(msg.nodeId);
    if (node) {
      pixso.viewport.scrollAndZoomIntoView([node]);
      pixso.currentPage.selection = [node];
    }
  }
};

async function findColorUsage() {
  const page = pixso.currentPage;
  if (!page) {
    pixso.ui.postMessage({ type: 'error', message: 'Нет активной страницы.' });
    return;
  }

  const localComponents = page.findAllWithCriteria({
    types: ['COMPONENT', 'COMPONENT_SET']
  });

  const components = localComponents.filter(
    (n) => n.type === 'COMPONENT' || n.type === 'COMPONENT_SET'
  );

  const total = components.length;
  const results = []; // { componentId, componentName, nodeId, nodeName, sourceType, detail }

  pixso.ui.postMessage({
    type: 'progress',
    current: 0,
    total,
    label: 'Поиск компонентов…'
  });

  for (let i = 0; i < components.length; i++) {
    const component = components[i];
    const componentLabel = component.name || `Component ${component.id}`;

    pixso.ui.postMessage({
      type: 'progress',
      current: i,
      total,
      label: `Проверка: ${componentLabel}`
    });

    await new Promise((r) => setTimeout(r, 0));

    await walkNode(component, component, results);
  }

  pixso.ui.postMessage({
    type: 'progress',
    current: total,
    total,
    label: 'Готово'
  });

  pixso.ui.postMessage({ type: 'results', results });
}

/**
 * Рекурсивный обход узла.
 * Проверяет заливки (fills) и обводки (strokes) — и стилевые, и прямые.
 */
async function walkNode(node, rootComponent, results) {
  // ----- ПРОВЕРКА ЗАЛИВОК (FILLS) -----
  const fillStyleId = node.fillStyleId;
  if (fillStyleId && fillStyleId !== pixso.mixed) {
    const style = await pixso.getStyleByIdAsync(fillStyleId);
    if (style && style.type === 'PAINT' && style.paints) {
      if (style.paints.some((p) => isTargetPaint(p))) {
        results.push({
          componentId: rootComponent.id,
          componentName: rootComponent.name || `Component ${rootComponent.id}`,
          nodeId: node.id,
          nodeName: node.name || `Node ${node.id}`,
          sourceType: 'fill (style)',
          detail: `${TARGET_HEX} @ ${TARGET_OPACITY}`
        });
      }
    }
  } else if (node.fills && node.fills !== pixso.mixed) {
    if (Array.isArray(node.fills) && node.fills.some((p) => isTargetPaint(p))) {
      results.push({
        componentId: rootComponent.id,
        componentName: rootComponent.name || `Component ${rootComponent.id}`,
        nodeId: node.id,
        nodeName: node.name || `Node ${node.id}`,
        sourceType: 'fill (direct)',
        detail: `${TARGET_HEX} @ ${TARGET_OPACITY}`
      });
    }
  }

  // ----- ПРОВЕРКА ОБВОДОК (STROKES) -----
  const strokeStyleId = node.strokeStyleId;
  if (strokeStyleId && strokeStyleId !== pixso.mixed) {
    const style = await pixso.getStyleByIdAsync(strokeStyleId);
    if (style && style.type === 'PAINT' && style.paints) {
      if (style.paints.some((p) => isTargetPaint(p))) {
        results.push({
          componentId: rootComponent.id,
          componentName: rootComponent.name || `Component ${rootComponent.id}`,
          nodeId: node.id,
          nodeName: node.name || `Node ${node.id}`,
          sourceType: 'stroke (style)',
          detail: `${TARGET_HEX} @ ${TARGET_OPACITY}`
        });
      }
    }
  } else if (node.strokes && node.strokes !== pixso.mixed) {
    if (Array.isArray(node.strokes) && node.strokes.some((p) => isTargetPaint(p))) {
      results.push({
        componentId: rootComponent.id,
        componentName: rootComponent.name || `Component ${rootComponent.id}`,
        nodeId: node.id,
        nodeName: node.name || `Node ${node.id}`,
        sourceType: 'stroke (direct)',
        detail: `${TARGET_HEX} @ ${TARGET_OPACITY}`
      });
    }
  }

  // Рекурсивный обход детей
  if (node.children && node.children.length > 0) {
    for (const child of node.children) {
      await walkNode(child, rootComponent, results);
    }
  }
}

/**
 * Проверяет, соответствует ли Paint целевому цвету и прозрачности.
 * Поддерживает только SolidPaint (сплошной цвет).
 */
function isTargetPaint(paint) {
  if (!paint || paint.type !== 'SOLID' || !paint.visible !== false) {
    // если visible === false, пропускаем (скрытые заливки не считаем)
    if (paint && paint.visible === false) return false;
  }

  const { color, opacity } = paint;
  if (!color) return false;

  // Сравниваем RGB с допуском
  const rMatch = Math.abs(color.r - targetRgb.r) <= COLOR_TOLERANCE;
  const gMatch = Math.abs(color.g - targetRgb.g) <= COLOR_TOLERANCE;
  const bMatch = Math.abs(color.b - targetRgb.b) <= COLOR_TOLERANCE;

  if (!(rMatch && gMatch && bMatch)) return false;

  // Если opacity не задан, считаем его равным 1 (полная непрозрачность).
  const paintOpacity = opacity === undefined ? 1 : opacity;

  // Сравниваем opacity с допуском
  return Math.abs(paintOpacity - TARGET_OPACITY) <= 0.01;
}

/**
 * Преобразует hex-строку в объект {r, g, b} с компонентами 0–1.
 */
function hexToRgb01(hex) {
  const cleaned = hex.replace('#', '');
  const bigint = parseInt(cleaned, 16);
  const r = ((bigint >> 16) & 255) / 255;
  const g = ((bigint >> 8) & 255) / 255;
  const b = (bigint & 255) / 255;
  return { r, g, b };
}