// main.js

pixso.showUI(__html__, { width: 400, height: 500 });

let isSearching = false;

pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'start-search') {
    if (isSearching) return;
    isSearching = true;

    try {
      await findColorUsage();
    } catch (err) {
      pixso.ui.postMessage({ type: 'error', message: err.message });
    } finally {
      isSearching = false;
    }
  }

  if (msg.type === 'navigate-to-node') {
    // msg.nodeId — id конкретного узла, где найден цвет
    const node = await pixso.getNodeByIdAsync(msg.nodeId);
    if (node) {
      pixso.viewport.scrollAndZoomIntoView([node]);
      pixso.currentPage.selection = [node];
    }
  }
};

async function findColorUsage() {
  const page = pixso.currentPage;
  if (!page) {
    pixso.ui.postMessage({ type: 'error', message: 'Нет активной страницы.' });
    return;
  }

  // 1. Получаем все локальные компоненты на странице
  const localComponents = page.findAllWithCriteria({
    types: ['COMPONENT', 'COMPONENT_SET']
  });

  const components = localComponents.filter(
    (n) => n.type === 'COMPONENT' || n.type === 'COMPONENT_SET'
  );

  const total = components.length;
  const results = []; // { componentId, componentName, nodeId, nodeName }

  pixso.ui.postMessage({
    type: 'progress',
    current: 0,
    total,
    label: 'Поиск компонентов…'
  });

  for (let i = 0; i < components.length; i++) {
    const component = components[i];
    const componentLabel = component.name || `Component ${component.id}`;

    pixso.ui.postMessage({
      type: 'progress',
      current: i,
      total,
      label: `Проверка: ${componentLabel}`
    });

    // Небольшая задержка, чтобы UI успевал обновиться
    await new Promise((r) => setTimeout(r, 0));

    // Рекурсивно обходим компонент и всех его потомков
    await walkNode(component, component, results);
  }

  pixso.ui.postMessage({
    type: 'progress',
    current: total,
    total,
    label: 'Готово'
  });

  pixso.ui.postMessage({
    type: 'results',
    results: results
  });
}

/**
 * Рекурсивный обход узла.
 * @param {SceneNode} node — текущий узел
 * @param {ComponentNode|ComponentSetNode} rootComponent — компонент, в котором идёт поиск
 * @param {Array} results — массив для сбора результатов
 */
async function walkNode(node, rootComponent, results) {
  // Проверяем заливки текущего узла
  const fillStyleId = node.fillStyleId;
  if (fillStyleId && fillStyleId !== pixso.mixed) {
    const style = await pixso.getStyleByIdAsync(fillStyleId);
    if (style && isTargetColorStyle(style)) {
      results.push({
        componentId: rootComponent.id,
        componentName: rootComponent.name || `Component ${rootComponent.id}`,
        nodeId: node.id,
        nodeName: node.name || `Node ${node.id}`
      });
    }
  }

  // Проверяем также прямые заливки (paints), если стиль не назначен,
  // но цвет совпадает напрямую — на случай, если цвет применён вручную.
  if (!fillStyleId && node.fills && node.fills !== pixso.mixed) {
    if (hasTargetColorInPaints(node.fills)) {
      results.push({
        componentId: rootComponent.id,
        componentName: rootComponent.name || `Component ${rootComponent.id}`,
        nodeId: node.id,
        nodeName: node.name || `Node ${node.id}`
      });
    }
  }

  // Рекурсивно обходим детей, если они есть
  if (node.children && node.children.length > 0) {
    for (const child of node.children) {
      await walkNode(child, rootComponent, results);
    }
  }
}

/**
 * Проверяет, является ли стиль цвета целевым (DarkNeutralAlpha.50).
 * Сравнение идёт по имени стиля.
 */
function isTargetColorStyle(style) {
  // Имя стиля может быть "DarkNeutralAlpha.50" или содержать его.
  const targetName = 'DarkNeutralAlpha.50';
  const name = style.name || '';
  return name === targetName || name.includes(targetName);
}

/**
 * Проверяет, есть ли в массиве Paint целевой цвет.
 * Сравнение идёт по имени стиля внутри Paint (если есть) или по hex-значению,
 * если известно. В Pixso Paint может содержать styleId, но имя стиля
 * надёжнее получать через getStyleByIdAsync.
 * Если стиль не назначен, но цвет задан напрямую — можно сравнить hex.
 * Здесь оставлено место для hex-сравнения, если вы знаете точный hex.
 */
function hasTargetColorInPaints(paints) {
  // Если цвет задан напрямую, сравните его hex-значение с эталоном.
  // Пример: return paints.some(p => p.type === 'SOLID' && p.color === '#XXXXXX');
  // Поскольку точный hex DarkNeutralAlpha.50 не указан, оставляем false.
  return false;
}