// code.js
pixso.showUI(__html__, { width: 420, height: 320 });

pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'export-tokens') {
    const format = msg.format; // 'DTCG' или 'LEGACY'
    await exportAllCollections(format);
  }
};

async function exportAllCollections(format) {
  const collections = await pixso.variables.getLocalVariableCollectionsAsync();
  
  if (collections.length === 0) {
    pixso.notify('В файле нет локальных коллекций переменных.');
    return;
  }

  for (const collection of collections) {
    const tokensJson = await buildCollectionTokens(collection, format);
    const safeName = collection.name.replace(/[^a-z0-9а-яё\-_]/gi, '_');
    const fileName = `${safeName}.tokens.json`;
    
    pixso.ui.postMessage({
      type: 'download',
      fileName,
      content: JSON.stringify(tokensJson, null, 2)
    });
  }

  pixso.notify(`Экспортировано ${collections.length} коллекций.`);
}

async function buildCollectionTokens(collection, format) {
  // Получаем все переменные этой коллекции
  const variables = await Promise.all(
    collection.variableIds.map(id => pixso.variables.getVariableByIdAsync(id))
  );

  const root = {};

  for (const variable of variables) {
    if (!variable) continue;
    
    const token = buildTokenValue(variable, collection, format);
    setNestedToken(root, variable.name, token);
  }

  return root;
}

function buildTokenValue(variable, collection, format) {
  const type = variable.resolvedType; // 'COLOR', 'FLOAT', 'STRING', 'BOOLEAN' и т.д.
  const valuesByMode = {};

  for (const mode of collection.modes) {
    const modeId = mode.modeId;
    const rawValue = variable.valuesByMode[modeId];
    
    if (rawValue && typeof rawValue === 'object' && 'type' in rawValue) {
      // Это алиас (reference) на другую переменную
      const aliasId = rawValue.id;
      const aliasVar = awaitVariableSync(aliasId); // псевдо-код, см. примечание ниже
      valuesByMode[mode.name] = `{${aliasVar?.name || aliasId}}`;
    } else {
      valuesByMode[mode.name] = rawValue;
    }
  }

  if (format === 'DTCG') {
    return {
      $type: mapTypeToDTCG(type),
      $value: valuesByMode[collection.modes[0].name], // значение по умолчанию
      $extensions: {
        modes: valuesByMode // все режимы для справки
      }
    };
  }

  // LEGACY формат (близкий к Tokens Studio "legacy")
  return {
    value: valuesByMode[collection.modes[0].name],
    type: mapTypeToLegacy(type),
    modes: valuesByMode
  };
}

function mapTypeToDTCG(pixsoType) {
  const map = {
    COLOR: 'color',
    FLOAT: 'dimension',
    STRING: 'string',
    BOOLEAN: 'boolean'
  };
  return map[pixsoType] || 'string';
}

function mapTypeToLegacy(pixsoType) {
  const map = {
    COLOR: 'color',
    FLOAT: 'spacing',
    STRING: 'text',
    BOOLEAN: 'boolean'
  };
  return map[pixsoType] || 'other';
}

function setNestedToken(root, path, token) {
  const parts = path.split('.');
  let current = root;
  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i];
    if (!current[part] || typeof current[part] !== 'object') {
      current[part] = {};
    }
    current = current[part];
  }
  current[parts[parts.length - 1]] = token;
}

// ⚠️ Примечание: API для синхронного получения переменной по ID может отличаться.
// В реальном коде используйте pixso.variables.getVariableByIdAsync(id) внутри async-цикла.
async function awaitVariableSync(aliasId) {
  return await pixso.variables.getVariableByIdAsync(aliasId);
}