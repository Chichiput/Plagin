pixso.showUI(__html__, { width: 480, height: 680 });

const varNameCache = new Map();

// Суффиксы, которые считаются «состояниями» и отрезаются для получения основного имени
const STATE_SUFFIXES = new Set([
  'default', 'hover', 'active', 'focus', 'focused', 'disabled', 'pressed', 'opened',
  'checked', 'checkedhover', 'hasvalue',
  'selected', 'selecteddefault', 'selectedhover', 'selectedactive', 'selecteddisabled', 'selectedfocus',
  'activedefault', 'activehover', 'activepressed', 'activedisabled',
  'defaulthover', 'defaultfocus', 'defaultlight', 'hoverlight', 'selectedlight',
  'lightselecteddefault', 'lightselectedhover', 'lightselectedactive',
  'lightselectedfocus', 'lightselecteddisabled',
  'darkselecteddefault', 'darkselectedhover', 'darkselectedactive',
  'darkselectedfocus', 'darkselecteddisabled'
]);

// Схлопывание: Button/Primary/Hover -> Button/Primary
//             Surface.Control.Trigger.General.Default -> Surface.Control.Trigger.General
function getMainName(name) {
  if (!name) return name;
  const sep = name.includes('/') ? '/' : '.';
  const parts = name.split(/[./]/);
  while (parts.length > 1 && STATE_SUFFIXES.has(parts[parts.length - 1].toLowerCase())) {
    parts.pop();
  }
  return parts.join(sep);
}

// ---------- 1. Локальные переменные ----------
async function buildLocalVariablesMap() {
  const localVars = await pixso.variables.getLocalVariablesAsync('COLOR');
  const byName = new Map();
  localVars.forEach(v => byName.set(v.name, v));
  return byName;
}

// ---------- 2. Имена библиотечных переменных ----------
async function buildLibraryVariableNameMap() {
  const nameMap = new Map();
  try {
    const collections = await pixso.teamLibrary.getAvailableLibraryVariableCollectionsAsync();
    for (const col of collections) {
      const libVars = await pixso.teamLibrary.getVariablesInLibraryCollectionAsync(col.key);
      for (const lv of libVars) {
        if (lv.id && lv.name) nameMap.set(lv.id, lv.name);
      }
    }
  } catch (e) {
    console.warn('teamLibrary недоступен:', e);
  }
  return nameMap;
}

// ---------- 3. Имя переменной по ID (с кэшем) ----------
async function resolveVariableName(varId, libraryNameMap) {
  if (varNameCache.has(varId)) return varNameCache.get(varId);
  const direct = await pixso.variables.getVariableByIdAsync(varId);
  let name = direct?.name || null;
  if (!name && libraryNameMap.has(varId)) name = libraryNameMap.get(varId);
  varNameCache.set(varId, name);
  return name;
}

// ---------- 4. Сбор имён токенов с узла (рекурсивно) ----------
async function collectNodeTokenNames(node, libraryNameMap, outSet) {
  if (node.fills && node.fills.length > 0) {
    for (const paint of node.fills) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const name = await resolveVariableName(paint.boundVariables.color.id, libraryNameMap);
        if (name) outSet.add(name);
      }
    }
  }
  if (node.strokes && node.strokes.length > 0) {
    for (const paint of node.strokes) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const name = await resolveVariableName(paint.boundVariables.color.id, libraryNameMap);
        if (name) outSet.add(name);
      }
    }
  }
  if ('children' in node) {
    for (const child of node.children) {
      await collectNodeTokenNames(child, libraryNameMap, outSet);
    }
  }
}

// ---------- 5. Скан всех компонентов страницы ----------
async function scanAllTokens() {
  const page = pixso.currentPage;
  if (!page) return { error: 'Не удалось получить текущую страницу.' };

  const localVarsByName = await buildLocalVariablesMap();
  const libraryNameMap = await buildLibraryVariableNameMap();

  const components = await page.findAllAsync(
    n => n.type === 'COMPONENT' || n.type === 'COMPONENT_SET'
  );

  const total = components.length;
  if (total === 0) {
    return { error: `На странице «${page.name}» не найдено компонентов.` };
  }

  pixso.ui.postMessage({ type: 'progress', current: 0, total, name: 'Подготовка...' });

  // tokenMainName -> Set(componentMainName)
  const usage = new Map();

  for (let i = 0; i < total; i++) {
    const comp = components[i];

    await new Promise(r => setTimeout(r, 0));

    if (i % 3 === 0 || i === total - 1) {
      pixso.ui.postMessage({ type: 'progress', current: i + 1, total, name: comp.name });
    }

    const compMain = getMainName(comp.name);
    const rawTokens = new Set();

    if (comp.type === 'COMPONENT_SET') {
      for (const variant of comp.children) {
        if (variant.type === 'COMPONENT') {
          await collectNodeTokenNames(variant, libraryNameMap, rawTokens);
        }
      }
    } else {
      await collectNodeTokenNames(comp, libraryNameMap, rawTokens);
    }

    for (const rawToken of rawTokens) {
      const mainToken = getMainName(rawToken);
      if (!usage.has(mainToken)) usage.set(mainToken, new Set());
      usage.get(mainToken).add(compMain);
    }
  }

  const tokens = [];
  for (const [name, compSet] of usage.entries()) {
    tokens.push({
      name,
      isLocal: localVarsByName.has(name) ||
               Array.from(localVarsByName.keys()).some(k => getMainName(k) === name),
      components: Array.from(compSet).sort()
    });
  }

  tokens.sort((a, b) => {
    if (a.isLocal !== b.isLocal) return a.isLocal ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  return {
    tokens,
    pageName: page.name,
    totalComponents: total,
    totalTokens: tokens.length,
    localTokensUsed: tokens.filter(t => t.isLocal).length,
    externalTokensUsed: tokens.filter(t => !t.isLocal).length
  };
}

// ---------- 6. Обработка сообщений ----------
pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'load-tokens') {
    const localVarsByName = await buildLocalVariablesMap();
    pixso.ui.postMessage({ type: 'tokens-count', count: localVarsByName.size });
  }

  if (msg.type === 'scan-all') {
    try {
      varNameCache.clear();
      const result = await scanAllTokens();
      if (result.error) {
        pixso.ui.postMessage({ type: 'error', message: result.error });
      } else {
        pixso.ui.postMessage({ type: 'scan-result', ...result });
      }
    } catch (e) {
      pixso.ui.postMessage({ type: 'error', message: e.message });
    }
  }
};