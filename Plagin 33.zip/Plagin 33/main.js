pixso.showUI(__html__, { width: 440, height: 620 });

// Кэш: variableId -> имя (или null, если не удалось получить)
const varNameCache = new Map();

// ---------- 1. Сбор локальных переменных ----------
async function buildLocalVariablesMap() {
  const localVars = await pixso.variables.getLocalVariablesAsync('COLOR');
  const byName = new Map();
  localVars.forEach(v => byName.set(v.name, v));
  return byName;
}

// ---------- 2. Сбор имён библиотечных переменных ----------
async function buildLibraryVariableNameMap() {
  const nameMap = new Map();
  try {
    const collections = await pixso.teamLibrary.getAvailableLibraryVariableCollectionsAsync();
    for (const col of collections) {
      const libVars = await pixso.teamLibrary.getVariablesInLibraryCollectionAsync(col.key);
      for (const lv of libVars) {
        if (lv.id && lv.name) nameMap.set(lv.id, lv.name);
      }
    }
  } catch (e) {
    console.warn('teamLibrary недоступен:', e);
  }
  return nameMap;
}

// ---------- 3. Получить имя переменной по ID (с кэшем) ----------
async function resolveVariableName(varId, libraryNameMap) {
  if (varNameCache.has(varId)) return varNameCache.get(varId);

  const direct = await pixso.variables.getVariableByIdAsync(varId);
  let name = direct?.name || null;

  if (!name && libraryNameMap.has(varId)) {
    name = libraryNameMap.get(varId);
  }

  varNameCache.set(varId, name);
  return name;
}

// ---------- 4. Проверка одного слоя ----------
async function nodeUsesToken(node, targetTokenName, libraryNameMap) {
  if (node.fills && node.fills.length > 0) {
    for (const paint of node.fills) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const name = await resolveVariableName(paint.boundVariables.color.id, libraryNameMap);
        if (name === targetTokenName) return true;
      }
    }
  }

  if (node.strokes && node.strokes.length > 0) {
    for (const paint of node.strokes) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const name = await resolveVariableName(paint.boundVariables.color.id, libraryNameMap);
        if (name === targetTokenName) return true;
      }
    }
  }

  if ('children' in node) {
    for (const child of node.children) {
      if (await nodeUsesToken(child, targetTokenName, libraryNameMap)) return true;
    }
  }

  return false;
}

// ---------- 5. Поиск по компонентам текущей страницы ----------
async function findComponentsUsingToken(targetTokenName, libraryNameMap) {
  const page = pixso.currentPage;
  if (!page) {
    return { error: 'Не удалось получить текущую страницу.' };
  }

  // Только компоненты — фреймы, прямоугольники и прочие объекты игнорируются
  const components = await page.findAllAsync(
    n => n.type === 'COMPONENT' || n.type === 'COMPONENT_SET'
  );

  const total = components.length;

  if (total === 0) {
    return { error: `На странице «${page.name}» не найдено компонентов.` };
  }

  // Стартовое сообщение о прогрессе
  pixso.ui.postMessage({
    type: 'progress',
    current: 0,
    total,
    name: 'Подготовка...'
  });

  const results = [];

  for (let i = 0; i < total; i++) {
    const comp = components[i];

    // Уступаем поток браузеру, чтобы UI успевал перерисовываться
    await new Promise(r => setTimeout(r, 0));

    // Обновляем прогресс каждые 3 компонента и на последнем
    if (i % 3 === 0 || i === total - 1) {
      pixso.ui.postMessage({
        type: 'progress',
        current: i + 1,
        total,
        name: comp.name
      });
    }

    let used = false;

    if (comp.type === 'COMPONENT_SET') {
      for (const variant of comp.children) {
        if (variant.type === 'COMPONENT' &&
            await nodeUsesToken(variant, targetTokenName, libraryNameMap)) {
          used = true;
          break;
        }
      }
    } else {
      used = await nodeUsesToken(comp, targetTokenName, libraryNameMap);
    }

    if (used) {
      results.push({ name: comp.name, type: comp.type, id: comp.id });
    }
  }

  return { results, pageName: page.name, total };
}

// ---------- 6. Обработка сообщений ----------
pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'load-tokens') {
    const localVarsByName = await buildLocalVariablesMap();
    const tokens = Array.from(localVarsByName.values()).map(v => ({
      name: v.name,
      id: v.id
    }));
    pixso.ui.postMessage({ type: 'tokens-loaded', tokens });
  }

  if (msg.type === 'find') {
    try {
      // Чистим кэш перед каждым новым запуском, чтобы не тащить старое
      varNameCache.clear();

      const libraryNameMap = await buildLibraryVariableNameMap();
      const result = await findComponentsUsingToken(msg.tokenName, libraryNameMap);

      if (result.error) {
        pixso.ui.postMessage({ type: 'error', message: result.error });
      } else {
        pixso.ui.postMessage({
          type: 'results',
          results: result.results,
          tokenName: msg.tokenName,
          pageName: result.pageName,
          total: result.total
        });
      }
    } catch (e) {
      pixso.ui.postMessage({ type: 'error', message: e.message });
    }
  }
};