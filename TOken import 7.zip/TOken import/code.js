// code.js — для Pixso (с поддержкой modes + таблица компонентов)
pixso.showUI(__html__, { width: 560, height: 780 });

// ================== КОНФИГ ==================
const CONFIG = {
  useColorHeuristic: false,

  // ---- Таблица компонентов ----
  // Корневой ключ, под которым таблица добавляется в конец экспорта
  tableRootKey: "components",
  // true → коллекции уходят под ключ "core": { "core": {...}, "components": {...} }
  wrapCollectionsInCore: false,

  primitiveCollectionPatterns: [
    /primitive/i,
    /^base/i,
    /foundation/i,
    /^core/i,
    /palette/i,
    /^colors?$/i,
    /^primitives?$/i,
    /tokens?\//i
  ]
};
// ===========================================

// ---------- Утилиты ----------

function isVariableAlias(value) {
  if (value === null || typeof value !== "object") return false;
  if (value.type === "VARIABLE_ALIAS") return true;
  if (
    typeof value.type === "string" &&
    value.type.toUpperCase() === "VARIABLE_ALIAS"
  ) return true;
  if (typeof value.id === "string" && value.id.startsWith("VariableID:")) {
    return true;
  }
  return false;
}

function isColorValue(value) {
  return (
    value !== null &&
    typeof value === "object" &&
    typeof value.r === "number" &&
    typeof value.g === "number" &&
    typeof value.b === "number"
  );
}

function rgbaToHex({ r, g, b, a = 1 }) {
  const to255 = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255);
  const hex = (n) => n.toString(16).padStart(2, "0").toUpperCase();
  const base = `#${hex(to255(r))}${hex(to255(g))}${hex(to255(b))}`;
  return a < 1 ? `${base}${hex(to255(a))}` : base;
}

async function getCollectionName(collectionId) {
  if (!collectionId) return "unknown-collection";
  try {
    const c = await pixso.variables.getVariableCollectionByIdAsync(collectionId);
    return c ? c.name : "unknown-collection";
  } catch (e) {
    return "unknown-collection";
  }
}

async function buildTokenPath(variable) {
  const collectionName = await getCollectionName(variable.variableCollectionId);
  const parts = variable.name.split("/").filter(Boolean);
  return [collectionName, ...parts].join(".");
}

async function resolveVariableById(id, localById) {
  const local = localById.get(id);
  if (local) return local;
  try {
    const remote = await pixso.variables.getVariableByIdAsync(id);
    return remote || null;
  } catch (e) {
    return null;
  }
}

/**
 * Вставка токена в итоговое дерево.
 * modeName === null  → один режим, имя не пишем.
 * modeName === "Light" и т.п. → создаём уровень режима.
 */
function insertToken(root, collectionName, variableName, value, modeName = null) {
  if (!root[collectionName]) root[collectionName] = {};

  let target = root[collectionName];

  if (modeName !== null) {
    if (!target[modeName]) target[modeName] = {};
    target = target[modeName];
  }

  const parts = variableName.split("/").filter(Boolean);
  const tokenName = parts.pop() || variableName;
  const folders = parts;

  for (const folder of folders) {
    if (!target[folder]) target[folder] = {};
    target = target[folder];
  }

  target[tokenName] = { "Value/ref": value };
}

function isPrimitiveCollection(name) {
  return CONFIG.primitiveCollectionPatterns.some((re) => re.test(name));
}

// ---------- Сбор ----------

async function collectAllTokens() {
  const result = {};
  const stats = {
    refs: 0,
    hexes: 0,
    heuristicRefs: 0,
    missingRefs: 0,
    total: 0,
    modes: 0,
    collections: 0
  };

  const collections = await pixso.variables.getLocalVariableCollectionsAsync();
  const allVariables = await pixso.variables.getLocalVariablesAsync();
  const localById = new Map(allVariables.map((v) => [v.id, v]));
  stats.collections = collections.length;

  console.log("=== DIAGNOSTIC: Collections ===");
  for (const c of collections) {
    console.log(
      `"${c.name}" id=${c.id} defaultModeId=${c.defaultModeId}`,
      "modes:", JSON.stringify(c.modes)
    );
  }

  // ---- Проход 1: собрать токены и продиагностировать ----
  const allTokens = [];

  for (const collection of collections) {
    const modes = collection.modes; // Array<{ modeId, name }>
    const hasMultipleModes = modes.length > 1;
    const variables = allVariables.filter(
      (v) => v.variableCollectionId === collection.id
    );

    for (const mode of modes) {
      const modeId = mode.modeId;
      const modeName = hasMultipleModes ? mode.name : null;

      for (const variable of variables) {
        const rawValue = variable.valuesByMode[modeId];
        if (rawValue === undefined) continue;

        const aliasByType = isVariableAlias(rawValue);
        const colorByShape = isColorValue(rawValue);

        // ---- ДИАГНОСТИКА ----
        console.log(
          "[VAR]",
          JSON.stringify(
            {
              collection: collection.name,
              modeName: modeName,
              variable: variable.name,
              resolvedType: variable.resolvedType,
              rawValueStringified: JSON.stringify(rawValue),
              isAliasByType: aliasByType,
              isColorByShape: colorByShape
            },
            null,
            2
          )
        );

        allTokens.push({
          collection: collection.name,
          variable,
          modeName,
          rawValue,
          isAlias: aliasByType,
          aliasId: aliasByType ? rawValue.id : null,
          path: [
            collection.name,
            ...variable.name.split("/").filter(Boolean)
          ]
        });
      }
    }
  }

  // ---- Эвристика: карта цвет → путь примитива ----
  let hexToPrimitivePath = null;
  if (CONFIG.useColorHeuristic) {
    hexToPrimitivePath = new Map();
    for (const t of allTokens) {
      if (!isPrimitiveCollection(t.collection)) continue;
      if (t.isAlias) continue;
      if (!isColorValue(t.rawValue)) continue;
      const hex = rgbaToHex(t.rawValue);
      if (!hexToPrimitivePath.has(hex)) {
        hexToPrimitivePath.set(hex, t.path);
      }
    }
    console.log(
      "[Heuristic] primitive color map size:",
      hexToPrimitivePath.size
    );
  }

  // ---- Проход 2: сформировать итоговое дерево ----
  for (const t of allTokens) {
    let value;

    if (t.isAlias) {
      const refVar = await resolveVariableById(t.aliasId, localById);
      if (refVar) {
        const refPath = await buildTokenPath(refVar);
        value = `{${refPath}}`;
        stats.refs++;
      } else {
        value = "#missing#";
        stats.missingRefs++;
      }
    } else if (
      t.variable.resolvedType === "COLOR" &&
      isColorValue(t.rawValue)
    ) {
      const hex = rgbaToHex(t.rawValue);

      if (
        hexToPrimitivePath &&
        !isPrimitiveCollection(t.collection) &&
        hexToPrimitivePath.has(hex)
      ) {
        const primPath = hexToPrimitivePath.get(hex);
        if (primPath.join("/") !== t.path.join("/")) {
          value = `{${primPath.join(".")}}`;
          stats.heuristicRefs++;
        } else {
          value = hex;
          stats.hexes++;
        }
      } else {
        value = hex;
        stats.hexes++;
      }
    } else {
      value = t.rawValue;
    }

    if (value === null || value === undefined) continue;

    insertToken(
      result,
      t.collection,
      t.variable.name,
      value,
      t.modeName // null или имя режима
    );
    stats.total++;
    if (t.modeName !== null) stats.modes++;
  }

  console.log("[Tokens Exporter] Stats:", stats);
  return { result, stats };
}

// ================== ТАБЛИЦА КОМПОНЕНТОВ ==================
// Формат: component | property | type | Light | Dark | ...
// type: ref → { "ref": "..." }, value → { "value": "..." }
// Результат: { "components": { "light": { Comp: { Prop: {ref|value: ...} } }, "dark": {...} } }

const TABLE_HEADER_ALIASES = {
  component: ["component", "компонент", "компоненты"],
  property: ["property", "свойство", "токен", "token"],
  type: ["type", "тип"],
  ignored: [
    "comment", "description", "описание", "примечание", "note", "комментарий"
  ]
};

const TABLE_TYPE_MAP = {
  ref: "ref",
  reference: "ref",
  alias: "ref",
  ссылка: "ref",
  value: "value",
  raw: "value",
  значение: "value"
};

// Разделитель: таб (вставка из таблиц), точка с запятой или запятая
function detectDelimiter(text) {
  const firstLine = text.split(/\r?\n/).find((line) => line.trim()) || "";
  const tabs = (firstLine.match(/\t/g) || []).length;
  const semicolons = (firstLine.match(/;/g) || []).length;
  const commas = (firstLine.match(/,/g) || []).length;
  if (tabs > 0) return "\t";
  if (semicolons > commas) return ";";
  return ",";
}

// CSV/TSV-парсер: кавычки, "" внутри кавычек, CRLF, BOM
function parseDelimited(text, delimiter) {
  const src = String(text || "").replace(/^\uFEFF/, "");
  const d = delimiter || detectDelimiter(src);
  const rows = [];
  let row = [];
  let cell = "";
  let inQuotes = false;

  for (let i = 0; i < src.length; i++) {
    const ch = src[i];

    if (inQuotes) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cell += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        cell += ch;
      }
      continue;
    }

    if (ch === '"') {
      inQuotes = true;
    } else if (ch === d) {
      row.push(cell);
      cell = "";
    } else if (ch === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else if (ch !== "\r") {
      cell += ch;
    }
  }

  row.push(cell);
  rows.push(row);
  return rows;
}

function findHeaderIndex(lowerHeaders, aliases) {
  for (const alias of aliases) {
    const index = lowerHeaders.indexOf(alias);
    if (index >= 0) return index;
  }
  return -1;
}

function inferType(value) {
  if (/^\{.*\}$/.test(value)) return "ref";
  if (/^[A-Za-z_][\w-]*(\/[\w.-]+)+$/.test(value)) return "ref";
  return "value";
}

/**
 * rows → { block, stats, warnings }
 * block = { light: { Comp: { Prop: { ref|value: "..." } } }, dark: {...} }
 */
function buildComponentTable(rows) {
  const warnings = [];
  const clean = [];

  (rows || []).forEach((row, index) => {
    const cells = (row || []).map((cell) =>
      String(cell == null ? "" : cell).trim()
    );
    if (cells.some((cell) => cell !== "")) {
      clean.push({ cells, line: index + 1 });
    }
  });

  if (!clean.length) throw new Error("таблица пуста");
  if (clean.length < 2) throw new Error("в таблице нет строк с данными");

  const header = clean[0].cells;
  const lower = header.map((cell) => cell.toLowerCase());

  const iComp = findHeaderIndex(lower, TABLE_HEADER_ALIASES.component);
  const iProp = findHeaderIndex(lower, TABLE_HEADER_ALIASES.property);
  const iType = findHeaderIndex(lower, TABLE_HEADER_ALIASES.type);

  if (iComp < 0) throw new Error('в шапке нет колонки "component"');
  if (iProp < 0) throw new Error('в шапке нет колонки "property"');

  const skippedCols = new Set(
    [iComp, iProp, iType].filter((index) => index >= 0)
  );
  TABLE_HEADER_ALIASES.ignored.forEach((alias) => {
    const index = lower.indexOf(alias);
    if (index >= 0) skippedCols.add(index);
  });

  const modeCols = [];
  header.forEach((name, index) => {
    if (skippedCols.has(index)) return;
    const trimmed = name.trim();
    if (!trimmed) return;
    modeCols.push({ index, mode: trimmed.toLowerCase() });
  });

  if (!modeCols.length) {
    throw new Error("в шапке нет колонок режимов (Light/Dark/...)");
  }
  if (new Set(modeCols.map((m) => m.mode)).size !== modeCols.length) {
    warnings.push("колонки режимов повторяются — значения смешаются");
  }

  const block = {};
  const stats = {
    rows: 0,
    tokens: 0,
    skipped: 0,
    components: 0,
    modes: modeCols.length
  };
  modeCols.forEach((m) => {
    block[m.mode] = {};
  });

  const seenComponents = new Set();

  for (let r = 1; r < clean.length; r++) {
    const { cells, line } = clean[r];
    const component = cells[iComp] || "";
    const property = cells[iProp] || "";

    if (!component || !property) {
      stats.skipped++;
      warnings.push(`строка ${line}: пустой компонент или свойство`);
      continue;
    }

    const rawType = iType >= 0 ? (cells[iType] || "") : "";
    let typeKey;

    if (!rawType) {
      typeKey = null; // определим по значению
    } else {
      typeKey = TABLE_TYPE_MAP[rawType.toLowerCase()] || null;
      if (!typeKey) {
        stats.skipped++;
        warnings.push(`строка ${line}: неизвестный тип "${rawType}"`);
        continue;
      }
    }

    stats.rows++;
    let written = 0;

    for (const m of modeCols) {
      const value = (cells[m.index] || "").trim();
      if (!value) continue;

      const effectiveType = typeKey || inferType(value);
      const target = block[m.mode];
      if (!target[component]) target[component] = {};

      if (target[component][property] !== undefined) {
        warnings.push(
          `строка ${line}: дубль ${component}.${property} (${m.mode}) — перезаписан`
        );
      }

      target[component][property] = { [effectiveType]: value };
      stats.tokens++;
      written++;
    }

    if (!written) {
      stats.skipped++;
      warnings.push(`строка ${line}: нет значений ни в одном режиме`);
    } else if (!seenComponents.has(component)) {
      seenComponents.add(component);
      stats.components++;
    }
  }

  if (!stats.tokens) throw new Error("в таблице не нашлось ни одного токена");

  return { block, stats, warnings };
}

// ---------- Таблица в экспорт ----------

let componentTable = null; // { block, stats, warnings, source }

function applyTableToResult(result) {
  if (!componentTable) return result;

  const rootKey = CONFIG.tableRootKey;
  const out = {};

  if (CONFIG.wrapCollectionsInCore) {
    out.core = result;
  } else {
    Object.keys(result).forEach((key) => {
      out[key] = result[key];
    });
  }

  const existing = result[rootKey];

  if (
    existing &&
    typeof existing === "object" &&
    !Array.isArray(existing) &&
    Object.keys(componentTable.block).every(
      (mode) =>
        existing[mode] === undefined ||
        (typeof existing[mode] === "object" && !Array.isArray(existing[mode]))
    )
  ) {
    // Коллекция с таким именем уже есть — добавляем режимы таблицы внутрь
    Object.keys(componentTable.block).forEach((mode) => {
      existing[mode] = Object.assign(
        existing[mode] || {},
        componentTable.block[mode]
      );
    });
    out[rootKey] = existing;
    componentTable.warnings.push(
      `коллекция "${rootKey}" уже существует — режимы таблицы добавлены в неё`
    );
  } else {
    out[rootKey] = componentTable.block;
  }

  return out;
}

// ---------- Сообщения ----------

pixso.ui.onmessage = async (msg) => {
  if (msg.type === "scan") {
    CONFIG.useColorHeuristic = !!msg.useHeuristic;
    try {
      const { result, stats } = await collectAllTokens();
      const data = applyTableToResult(result);
      pixso.ui.postMessage({
        type: "scan-result",
        data,
        stats: {
          collections: stats.collections,
          tokens: stats.total,
          refs: stats.refs,
          hexes: stats.hexes,
          heuristicRefs: stats.heuristicRefs,
          missingRefs: stats.missingRefs,
          modes: stats.modes,
          tableComponents: componentTable ? componentTable.stats.components : 0,
          tableTokens: componentTable ? componentTable.stats.tokens : 0
        }
      });
    } catch (err) {
      console.error("[Tokens Exporter] ERROR:", err);
      pixso.ui.postMessage({
        type: "scan-error",
        message: err.message || String(err)
      });
    }
  }

  if (msg.type === "table-load") {
    try {
      const rows = parseDelimited(msg.text);
      const built = buildComponentTable(rows);
      built.source = msg.source || "";
      componentTable = built;
      pixso.ui.postMessage({
        type: "table-result",
        source: built.source,
        stats: built.stats,
        modes: Object.keys(built.block),
        warnings: built.warnings.slice(0, 10)
      });
    } catch (err) {
      console.error("[Tokens Exporter] TABLE ERROR:", err);
      pixso.ui.postMessage({
        type: "table-error",
        message: err.message || String(err)
      });
    }
  }

  if (msg.type === "table-clear") {
    componentTable = null;
    pixso.ui.postMessage({ type: "table-result", cleared: true });
  }

  if (msg.type === "close") {
    pixso.closePlugin();
  }
};
