// main.js

pixso.showUI(__html__, { width: 420, height: 620 });

pixso.ui.onmessage = async (msg) => {
  if (msg.type === "start-scan") {
    await scanAllPages();
  }
};

// Рекурсивно собираем ВСЕ страницы, включая вложенные в FolderNode
function collectAllPages(node, result = []) {
  if (node.type === "PAGE") {
    result.push(node);
    return result;
  }
  // DocumentNode или FolderNode — идём глубже
  if (node.children && (node.type === "DOCUMENT" || node.type === "FOLDER")) {
    for (const child of node.children) {
      collectAllPages(child, result);
    }
  }
  return result;
}

async function scanAllPages() {
  const pages = collectAllPages(pixso.root);

  if (!pages.length) {
    pixso.ui.postMessage({ type: "error", message: "Страницы не найдены." });
    return;
  }

  const totalPages = pages.length;
  const lostInstances = [];

  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];

    pixso.ui.postMessage({
      type: "progress",
      current: i + 1,
      total: totalPages,
      pageName: page.name
    });

    // Даём UI отрисовать прогресс
    await new Promise((r) => setTimeout(r, 20));

    try {
      const allNodes = await page.findAllAsync();

      for (const node of allNodes) {
        // Интересуют ТОЛЬКО экземпляры
        if (node.type !== "INSTANCE") continue;

        // 🔍 ПРОВЕРЯЕМ ТОЛЬКО ПЕРВЫЙ КЕЙС: mainComponent === null
        if (node.mainComponent === null) {
          lostInstances.push({
            pageName: page.name,
            pageId: page.id,
            instanceName: node.name,
            instanceId: node.id,
            reason: "mainComponent = null"
          });
        }
      }
    } catch (err) {
      pixso.ui.postMessage({
        type: "warning",
        message: `Страница «${page.name}»: ${err.message}`
      });
    }
  }

  pixso.ui.postMessage({
    type: "result",
    data: lostInstances,
    totalPages: totalPages
  });
}