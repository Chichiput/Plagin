// main.js — логика плагина (выполняется в песочнице Pixso)

pixso.showUI(__html__, { width: 420, height: 540 });

// Обработка сообщений из UI
pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'collect') {
    await collectMapping();
  }
};

async function collectMapping() {
  const selection = pixso.currentPage.selection;

  if (!selection || selection.length === 0) {
    pixso.ui.postMessage({
      type: 'error',
      message: 'Ничего не выбрано. Выделите компоненты или компонент-сеты.'
    });
    return;
  }

  const results = [];

  for (const node of selection) {
    if (node.type === 'COMPONENT_SET') {
      // Компонент-сет — перебираем всех детей (варианты)
      for (const variant of node.children) {
        if (variant.type === 'COMPONENT') {
          const entry = await processVariant(variant, node.name);
          if (entry) results.push(entry);
        }
      }
    } else if (node.type === 'COMPONENT') {
      // Одиночный компонент (без сета)
      const entry = await processVariant(node, node.name);
      if (entry) results.push(entry);
    }
  }

  if (results.length === 0) {
    pixso.ui.postMessage({
      type: 'error',
      message: 'Не удалось собрать маппинг. Проверьте, что у компонентов есть варианты с именованными свойствами.'
    });
    return;
  }

  pixso.ui.postMessage({
    type: 'result',
    data: results
  });
}

/**
 * Обрабатывает один вариант компонента и возвращает строку маппинга.
 * @param {ComponentNode} variant — узел варианта
 * @param {string} componentName — имя родительского компонента (сета)
 * @returns {object|null}
 */
async function processVariant(variant, componentName) {
  const variantProps = variant.variantProperties || {};
  // variantProperties может быть null, если вариант не вложен в сет

  // Извлекаем Type и State (регистронезависимо)
  let type = '';
  let state = '';

  for (const [key, value] of Object.entries(variantProps)) {
    const lower = key.toLowerCase();
    if (lower.includes('type')) type = value;
    if (lower.includes('state')) state = value;
  }

  // Если не нашли — используем значения по умолчанию
  if (!type) type = 'Default';
  if (!state) state = 'Default';

  // Ищем атрибуты в слоях (например, слой "Icon" → атрибут "icon")
  const attributes = collectAttributes(variant);
  // Если атрибутов несколько, объединяем через дефис
  const attribute = attributes.length > 0 ? attributes.join('-') : 'default';

  // Формируем итоговый токен
  const token = `${componentName}_${type}_${attribute}_${state}`;

  return {
    token,
    component: componentName,
    type,
    attribute,
    state,
    variantId: variant.id,
    attributesFound: attributes
  };
}

/**
 * Рекурсивно обходит слои варианта и собирает имена, подходящие под атрибуты.
 * По умолчанию ищем слои с именами, содержащими "icon", "label", "text", "image".
 * Можно расширить список.
 */
function collectAttributes(node, found = []) {
  const ATTR_KEYWORDS = ['icon', 'label', 'text', 'image', 'avatar'];

  if (node.name) {
    const lower = node.name.toLowerCase();
    for (const kw of ATTR_KEYWORDS) {
      if (lower.includes(kw)) {
        // Приводим к единому виду: "Icon" → "icon"
        const clean = lower.replace(/[^a-z0-9]/g, '');
        if (!found.includes(clean)) {
          found.push(clean);
        }
        break;
      }
    }
  }

  if (node.children) {
    for (const child of node.children) {
      collectAttributes(child, found);
    }
  }

  return found;
}