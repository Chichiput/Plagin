pixso.showUI(__html__, { width: 460, height: 600 });

pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'collect') {
    try {
      await collectMapping();
    } catch (e) {
      pixso.ui.postMessage({ type: 'error', message: 'Ошибка: ' + (e.message || e) });
    }
  }
};

async function collectMapping() {
  const selection = pixso.currentPage.selection;

  if (!selection || selection.length === 0) {
    pixso.ui.postMessage({
      type: 'error',
      message: 'Ничего не выбрано. Выделите компоненты или компонент-сеты.'
    });
    return;
  }

  const result = {};

  for (const node of selection) {
    if (node.type === 'COMPONENT_SET') {
      const componentKey = cleanComponentName(node.name);
      if (!result[componentKey]) result[componentKey] = {};

      for (const variant of node.children) {
        if (variant.type !== 'COMPONENT') continue;
        const mappings = await processVariant(variant);
        for (const [k, v] of Object.entries(mappings)) {
          // если ключ уже есть — оставляем первый (варианты с одинаковыми Type/State не должны конфликтовать)
          if (!result[componentKey][k]) result[componentKey][k] = v;
        }
      }
    } else if (node.type === 'COMPONENT') {
      const componentKey = cleanComponentName(node.name);
      if (!result[componentKey]) result[componentKey] = {};
      const mappings = await processVariant(node);
      for (const [k, v] of Object.entries(mappings)) {
        if (!result[componentKey][k]) result[componentKey][k] = v;
      }
    }
  }

  const hasAny = Object.values(result).some(obj => Object.keys(obj).length > 0);
  if (!hasAny) {
    pixso.ui.postMessage({
      type: 'error',
      message: 'Не найдено цветовых токенов. Проверьте, что слои привязаны к цветовым стилям или переменным.'
    });
    return;
  }

  pixso.ui.postMessage({ type: 'result', data: result });
}

/**
 * Обходит варианты одного компонента и собирает маппинг цветовых токенов.
 * Возвращает объект: { "Type_Attribute_State": { ref: "ColorToken" }, ... }
 */
async function processVariant(variant) {
  const variantProps = variant.variantProperties || {};

  let type = '';
  let state = '';
  for (const [key, value] of Object.entries(variantProps)) {
    const lower = key.toLowerCase();
    if (lower.includes('type')) type = value;
    if (lower.includes('state')) state = value;
  }
  if (!type) type = 'Default';
  if (!state) state = 'Default';

  // Собираем слои внутри варианта, пропуская INSTANCE (встроенные компоненты)
  const layers = [];
  const walk = (n, isRoot) => {
    if (!isRoot) {
      // Пропускаем встроенные компоненты и инстансы
      if (n.type === 'INSTANCE') return;
      if (n.type === 'COMPONENT') return;
      layers.push(n);
    }
    if (n.children) {
      for (const c of n.children) walk(c, false);
    }
  };
  walk(variant, true);

  // attribute -> [ {kind, ref} ]
  const layerTokens = {};

  for (const layer of layers) {
    const tokens = await getLayerColorTokens(layer);
    if (tokens.length === 0) continue;

    const attribute = cleanAttribute(layer.name);
    if (!attribute) continue;

    if (!layerTokens[attribute]) layerTokens[attribute] = [];
    layerTokens[attribute].push(...tokens);
  }

  const mappings = {};
  for (const [attribute, tokens] of Object.entries(layerTokens)) {
    for (const token of tokens) {
      let key = `${type}_${attribute}_${state}`;
      if (tokens.length > 1) {
        // если на одном слое несколько токенов (fill + stroke) — различаем суффиксом
        key = `${key}_${token.kind}`;
      }
      // на случай дубликатов
      let finalKey = key;
      let i = 1;
      while (mappings[finalKey]) {
        finalKey = `${key}_${i++}`;
      }
      mappings[finalKey] = { ref: token.ref };
    }
  }

  return mappings;
}

/**
 * Возвращает массив цветовых токенов, привязанных к слою (fills + strokes).
 * [{ kind: 'fill'|'stroke', ref: 'ColorTokenName' }, ...]
 */
async function getLayerColorTokens(node) {
  const tokens = [];

  // ---- FILLS ----
  if (Array.isArray(node.fills) && node.fills.length > 0) {
    const visibleFills = node.fills.filter(f => f.visible !== false);
    if (visibleFills.length > 0) {
      // 1) Переменные на конкретной заливке
      let foundVar = false;
      for (const fill of visibleFills) {
        const bv = fill.boundVariables && fill.boundVariables.color;
        if (bv && bv.id) {
          const v = await getVariableSafe(bv.id);
          if (v && v.name) {
            tokens.push({ kind: 'fill', ref: v.name });
            foundVar = true;
            break;
          }
        }
      }
      // 2) Цветовой стиль на ноде
      if (!foundVar && node.fillStyleId) {
        const style = await getStyleSafe(node.fillStyleId);
        if (style && style.name) tokens.push({ kind: 'fill', ref: style.name });
      }
    }
  }

  // ---- STROKES ----
  if (Array.isArray(node.strokes) && node.strokes.length > 0) {
    const visibleStrokes = node.strokes.filter(s => s.visible !== false);
    if (visibleStrokes.length > 0) {
      let foundVar = false;
      for (const stroke of visibleStrokes) {
        const bv = stroke.boundVariables && stroke.boundVariables.color;
        if (bv && bv.id) {
          const v = await getVariableSafe(bv.id);
          if (v && v.name) {
            tokens.push({ kind: 'stroke', ref: v.name });
            foundVar = true;
            break;
          }
        }
      }
      if (!foundVar && node.strokeStyleId) {
        const style = await getStyleSafe(node.strokeStyleId);
        if (style && style.name) tokens.push({ kind: 'stroke', ref: style.name });
      }
    }
  }

  return tokens;
}

// ---------- safe-обёртки над API Pixso ----------

async function getStyleSafe(id) {
  if (!id) return null;
  try {
    if (typeof pixso.getStyleByIdAsync === 'function') {
      return await pixso.getStyleByIdAsync(id);
    }
  } catch (e) {}
  try {
    if (typeof pixso.getStyleById === 'function') {
      return pixso.getStyleById(id);
    }
  } catch (e) {}
  return null;
}

async function getVariableSafe(id) {
  if (!id) return null;
  try {
    if (pixso.variables && typeof pixso.variables.getVariableByIdAsync === 'function') {
      return await pixso.variables.getVariableByIdAsync(id);
    }
  } catch (e) {}
  return null;
}

// ---------- нормализация имён ----------

function cleanComponentName(name) {
  return String(name || '')
    .toLowerCase()
    .replace(/\s+/g, '_')
    .replace(/[^a-z0-9а-яё_]/gi, '')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

function cleanAttribute(name) {
  return String(name || '')
    .trim()
    .replace(/\s+/g, '_')
    .replace(/[^a-zA-Z0-9а-яёА-ЯЁ_]/g, '')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}