pixso.showUI(__html__, { width: 420, height: 560 });

// Получить все локальные цветовые переменные (токены)
async function getColorTokens() {
  const vars = await pixso.variables.getLocalVariablesAsync('COLOR');
  return vars.map(v => ({ id: v.id, name: v.name }));
}

// Рекурсивно проверить, использует ли узел выбранный токен
function nodeUsesToken(node, tokenId) {
  if (node.fillStyleId === tokenId) return true;
  if (node.strokeStyleId === tokenId) return true;

  if ('children' in node) {
    for (const child of node.children) {
      if (nodeUsesToken(child, tokenId)) return true;
    }
  }
  return false;
}

// Сканировать ВЕСЬ файл: все страницы, все компоненты
async function findComponentsUsingToken(tokenId) {
  const results = [];
  const pages = pixso.root.children; // все страницы документа

  for (const page of pages) {
    // findAllAsync — актуальный метод для Pixso 2.0 
    const components = await page.findAllAsync(
      n => n.type === 'COMPONENT' || n.type === 'COMPONENT_SET'
    );

    for (const comp of components) {
      let used = false;

      if (comp.type === 'COMPONENT_SET') {
        for (const variant of comp.children) {
          if (variant.type === 'COMPONENT' && nodeUsesToken(variant, tokenId)) {
            used = true;
            break;
          }
        }
      } else {
        used = nodeUsesToken(comp, tokenId);
      }

      if (used) {
        results.push({
          name: comp.name,
          id: comp.id,
          type: comp.type,
          pageName: page.name
        });
      }
    }
  }

  return results;
}

pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'load-tokens') {
    const tokens = await getColorTokens();
    pixso.ui.postMessage({ type: 'tokens-loaded', tokens });
  }

  if (msg.type === 'find') {
    const results = await findComponentsUsingToken(msg.tokenId);
    pixso.ui.postMessage({
      type: 'results',
      results,
      tokenName: msg.tokenName
    });
  }
};