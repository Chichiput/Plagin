// code.js — для Pixso
pixso.showUI(__html__, { width: 560, height: 640 });

// ---------- Утилиты ----------

function isVariableAlias(value) {
  return (
    value !== null &&
    typeof value === "object" &&
    value.type === "VARIABLE_ALIAS" &&
    typeof value.id === "string"
  );
}

function rgbaToHex({ r, g, b, a = 1 }) {
  const to255 = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255);
  const hex = (n) => n.toString(16).padStart(2, "0").toUpperCase();
  const base = `#${hex(to255(r))}${hex(to255(g))}${hex(to255(b))}`;
  return a < 1 ? `${base}${hex(to255(a))}` : base;
}

async function getCollectionName(collectionId) {
  if (!collectionId) return "unknown-collection";
  try {
    const c = await pixso.variables.getVariableCollectionByIdAsync(collectionId);
    return c ? c.name : "unknown-collection";
  } catch (e) {
    return "unknown-collection";
  }
}

async function buildTokenPath(variable) {
  const collectionName = await getCollectionName(variable.variableCollectionId);
  const parts = variable.name.split("/").filter(Boolean);
  return [collectionName, ...parts].join(".");
}

async function resolveVariableById(id, localById) {
  const local = localById.get(id);
  if (local) return local;
  try {
    const remote = await pixso.variables.getVariableByIdAsync(id);
    return remote || null;
  } catch (e) {
    return null;
  }
}

async function normalizeValue(value, variable, localById, stats) {
  if (value === undefined || value === null) return null;

  // 1. Алиас на другой токен — показываем ИМЯ токена, не HEX
  if (isVariableAlias(value)) {
    const refVar = await resolveVariableById(value.id, localById);
    if (refVar) {
      const refPath = await buildTokenPath(refVar);
      stats.refs++;
      return `{${refPath}}`;
    }
    stats.missingRefs++;
    return "#missing#";
  }

  // 2. Обычный цвет — HEX
  if (
    variable.resolvedType === "COLOR" &&
    typeof value === "object" &&
    "r" in value
  ) {
    stats.hexes++;
    return rgbaToHex(value);
  }

  // 3. Числа, строки, булевы — как есть
  return value;
}

function insertToken(root, collectionName, variableName, value) {
  const parts = variableName.split("/").filter(Boolean);
  const tokenName = parts.pop() || variableName;
  const folders = parts;

  if (!root[collectionName]) root[collectionName] = {};
  let current = root[collectionName];
  for (const folder of folders) {
    if (!current[folder]) current[folder] = {};
    current = current[folder];
  }
  current[tokenName] = { "Value/ref": value };
}

// ---------- Основной сбор ----------

async function collectAllTokens() {
  const result = {};
  const stats = { refs: 0, hexes: 0, missingRefs: 0, total: 0 };

  const collections = await pixso.variables.getLocalVariableCollectionsAsync();
  const allVariables = await pixso.variables.getLocalVariablesAsync();
  const localById = new Map(allVariables.map((v) => [v.id, v]));

  console.log(
    `[Tokens Exporter] Collections: ${collections.length}, Variables: ${allVariables.length}`
  );

  for (const collection of collections) {
    const modeId = collection.defaultModeId;
    const variables = allVariables.filter(
      (v) => v.variableCollectionId === collection.id
    );

    for (const variable of variables) {
      const rawValue = variable.valuesByMode[modeId];

      // Отладка: если в консоли видно VARIABLE_ALIAS — ссылки будут именем токена
      console.log(
        `[Token] ${collection.name} → ${variable.name}`,
        { resolvedType: variable.resolvedType, rawValue }
      );

      const normalized = await normalizeValue(
        rawValue,
        variable,
        localById,
        stats
      );

      if (normalized === null) continue;

      insertToken(result, collection.name, variable.name, normalized);
      stats.total++;
    }
  }

  console.log("[Tokens Exporter] Stats:", stats);
  return { result, stats };
}

// ---------- Сообщения ----------

pixso.ui.onmessage = async (msg) => {
  if (msg.type === "scan") {
    try {
      const { result, stats } = await collectAllTokens();
      pixso.ui.postMessage({
        type: "scan-result",
        data: result,
        stats: {
          collections: Object.keys(result).length,
          tokens: stats.total,
          refs: stats.refs,
          hexes: stats.hexes,
          missingRefs: stats.missingRefs,
        },
      });
    } catch (err) {
      console.error("[Tokens Exporter] ERROR:", err);
      pixso.ui.postMessage({
        type: "scan-error",
        message: err.message || String(err),
      });
    }
  }

  if (msg.type === "close") {
    pixso.closePlugin();
  }
};