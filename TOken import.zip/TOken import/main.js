// code.js

figma.showUI(__html__, { width: 560, height: 640 });

/**
 * Приводит значение переменной к строке, пригодной для JSON.
 * Для цветов возвращает HEX, для алиасов — ссылку на токен.
 */
function normalizeValue(value, variable, allVariablesById) {
  if (value === undefined || value === null) return null;

  // Алиас (ссылка на другую переменную)
  if (typeof value === "object" && value.type === "VARIABLE_ALIAS") {
    const refVar = allVariablesById.get(value.id);
    if (refVar) {
      // Возвращаем путь к токену в формате {collection.folder.token}
      const refPath = buildTokenPath(refVar, allVariablesById);
      return `{${refPath}}`;
    }
    return "#missing#";
  }

  // Цвет (Figma хранит каналы 0..1)
  if (variable.resolvedType === "COLOR" && typeof value === "object" && "r" in value) {
    return rgbaToHex(value);
  }

  // Числа, строки, булевы
  return value;
}

/**
 * Строит путь к токену в формате collection.folder.token
 */
function buildTokenPath(variable, allVariablesById) {
  const collection = figma.variables.getVariableCollectionById(variable.variableCollectionId);
  const collectionName = collection ? collection.name : "unknown-collection";

  const parts = variable.name.split("/").filter(Boolean);
  const tokenName = parts.pop() || variable.name;
  const folders = parts;

  return [collectionName, ...folders, tokenName].join(".");
}

/**
 * Преобразует {r,g,b,a} (0..1) в HEX-строку.
 */
function rgbaToHex({ r, g, b, a = 1 }) {
  const to255 = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255);
  const hex = (n) => n.toString(16).padStart(2, "0").toUpperCase();
  const base = `#${hex(to255(r))}${hex(to255(g))}${hex(to255(b))}`;
  return a < 1 ? `${base}${hex(to255(a))}` : base;
}

/**
 * Вставляет токен в иерархическую структуру:
 * {
 *   "Collection": {
 *     "folder": {
 *       "tokenName": { "Value/ref": "..." }
 *     }
 *   }
 * }
 */
function insertToken(root, collectionName, variableName, value) {
  const parts = variableName.split("/").filter(Boolean);
  const tokenName = parts.pop() || variableName;
  const folders = parts;

  if (!root[collectionName]) root[collectionName] = {};

  let current = root[collectionName];
  for (const folder of folders) {
    if (!current[folder]) current[folder] = {};
    current = current[folder];
  }

  current[tokenName] = { "Value/ref": value };
}

/**
 * Главная функция сбора всех коллекций и переменных.
 */
async function collectAllTokens() {
  const result = {};

  const collections = await figma.variables.getLocalVariableCollectionsAsync();
  const allVariables = await figma.variables.getLocalVariablesAsync();

  const allVariablesById = new Map(allVariables.map((v) => [v.id, v]));

  for (const collection of collections) {
    // Используем режим по умолчанию
    const modeId = collection.defaultModeId;

    // Получаем переменные именно этой коллекции
    const variables = allVariables.filter(
      (v) => v.variableCollectionId === collection.id
    );

    for (const variable of variables) {
      const rawValue = variable.valuesByMode[modeId];
      const normalized = normalizeValue(rawValue, variable, allVariablesById);

      // Пропускаем null (например, если значение не задано)
      if (normalized === null) continue;

      insertToken(result, collection.name, variable.name, normalized);
    }
  }

  return result;
}

// Обработка сообщений из UI
figma.ui.onmessage = async (msg) => {
  if (msg.type === "scan") {
    try {
      const data = await collectAllTokens();
      figma.ui.postMessage({
        type: "scan-result",
        data,
        stats: {
          collections: Object.keys(data).length,
          tokens: countTokens(data),
        },
      });
    } catch (err) {
      figma.ui.postMessage({
        type: "scan-error",
        message: err.message || String(err),
      });
    }
  }

  if (msg.type === "close") {
    figma.closePlugin();
  }
};

/** Подсчёт общего количества токенов (для статистики в UI) */
function countTokens(obj) {
  let count = 0;
  for (const key in obj) {
    const val = obj[key];
    if (val && typeof val === "object" && "Value/ref" in val) {
      count++;
    } else if (val && typeof val === "object") {
      count += countTokens(val);
    }
  }
  return count;
}