// main.js
// Плагин для Pixso: экспорт всех локальных стилей в JSON и импорт в другой файл.

pixso.showUI(__html__, { width: 320, height: 240 });

const PLUGIN_MSG = {
  EXPORT: 'export',
  IMPORT: 'import',
  STATUS: 'status',
};

function sendStatus(text) {
  pixso.ui.postMessage({ type: PLUGIN_MSG.STATUS, text });
}

// ---------- ЭКСПОРТ ----------

async function exportAllStyles() {
  const result = {
    meta: {
      exportedAt: new Date().toISOString(),
      fileKey: pixso.fileKey || null,
      apiVersion: pixso.apiVersion,
    },
    paintStyles: [],
    textStyles: [],
    effectStyles: [],
    gridStyles: [],
  };

  // 1. Цветовые стили (PaintStyle)
  const paintStyles = pixso.getLocalPaintStyles();
  for (const style of paintStyles) {
    result.paintStyles.push({
      name: style.name,
      description: style.description || '',
      paints: style.paints.map(serializePaint),
    });
  }

  // 2. Текстовые стили (TextStyle)
  const textStyles = pixso.getLocalTextStyles();
  for (const style of textStyles) {
    result.textStyles.push({
      name: style.name,
      description: style.description || '',
      fontName: style.fontName,
      fontSize: style.fontSize,
      letterSpacing: style.letterSpacing,
      lineHeight: style.lineHeight,
      paragraphSpacing: style.paragraphSpacing,
      textDecoration: style.textDecoration,
      textCase: style.textCase,
    });
  }

  // 3. Эффекты (EffectStyle)
  const effectStyles = pixso.getLocalEffectStyles();
  for (const style of effectStyles) {
    result.effectStyles.push({
      name: style.name,
      description: style.description || '',
      effects: style.effects.map(serializeEffect),
    });
  }

  // 4. Сетки (GridStyle)
  const gridStyles = pixso.getLocalGridStyles();
  for (const style of gridStyles) {
    result.gridStyles.push({
      name: style.name,
      description: style.description || '',
      grids: style.layoutGrids.map(serializeGrid),
    });
  }

  sendStatus(
    `Готово: ${result.paintStyles.length} цветовых, ` +
    `${result.textStyles.length} текстовых, ` +
    `${result.effectStyles.length} эффектов, ` +
    `${result.gridStyles.length} сеток.`
  );

  return result;
}

// Вспомогательные сериализаторы (защита от циклических ссылок и неподдерживаемых полей)
function serializePaint(paint) {
  const out = { ...paint };
  delete out.boundVariables;
  return out;
}

function serializeEffect(effect) {
  const out = { ...effect };
  delete out.boundVariables;
  return out;
}

function serializeGrid(grid) {
  return { ...grid };
}

// ---------- ИМПОРТ ----------

async function importAllStyles(jsonString) {
  let data;
  try {
    data = JSON.parse(jsonString);
  } catch (e) {
    sendStatus('Ошибка: файл не является корректным JSON.');
    return;
  }

  let created = 0;
  let skipped = 0;

  // 1. Цветовые стили
  for (const item of data.paintStyles || []) {
    try {
      const style = pixso.createPaintStyle();
      style.name = item.name;
      if (item.description) style.description = item.description;
      style.paints = item.paints;
      created++;
    } catch (e) {
      skipped++;
      console.warn('PaintStyle skip:', item.name, e);
    }
  }

  // 2. Текстовые стили — обязательно загружаем шрифт
  for (const item of data.textStyles || []) {
    try {
      const style = pixso.createTextStyle();
      style.name = item.name;
      if (item.description) style.description = item.description;

      if (item.fontName) {
        await pixso.loadFontAsync(item.fontName);
        style.fontName = item.fontName;
      }
      if (item.fontSize != null) style.fontSize = item.fontSize;
      if (item.letterSpacing) style.letterSpacing = item.letterSpacing;
      if (item.lineHeight) style.lineHeight = item.lineHeight;
      if (item.paragraphSpacing != null) style.paragraphSpacing = item.paragraphSpacing;
      if (item.textDecoration) style.textDecoration = item.textDecoration;
      if (item.textCase) style.textCase = item.textCase;

      created++;
    } catch (e) {
      skipped++;
      console.warn('TextStyle skip:', item.name, e);
    }
  }

  // 3. Стили эффектов
  for (const item of data.effectStyles || []) {
    try {
      const style = pixso.createEffectStyle();
      style.name = item.name;
      if (item.description) style.description = item.description;
      style.effects = item.effects;
      created++;
    } catch (e) {
      skipped++;
      console.warn('EffectStyle skip:', item.name, e);
    }
  }

  // 4. Стили сеток
  for (const item of data.gridStyles || []) {
    try {
      const style = pixso.createGridStyle();
      style.name = item.name;
      if (item.description) style.description = item.description;
      style.layoutGrids = item.grids;
      created++;
    } catch (e) {
      skipped++;
      console.warn('GridStyle skip:', item.name, e);
    }
  }

  sendStatus(`Импорт завершён: создано ${created}, пропущено ${skipped}.`);
}

// ---------- ОБРАБОТКА СООБЩЕНИЙ ОТ UI ----------

pixso.ui.onmessage = async (msg) => {
  if (!msg || !msg.type) return;

  if (msg.type === PLUGIN_MSG.EXPORT) {
    const data = await exportAllStyles();
    // Отправляем JSON обратно в UI для скачивания
    pixso.ui.postMessage({ type: 'download', json: JSON.stringify(data, null, 2) });
  }

  if (msg.type === PLUGIN_MSG.IMPORT) {
    await importAllStyles(msg.data);
  }
};

// ---------- ДОПОЛНИТЕЛЬНЫЙ КОД В UI ДЛЯ СКАЧИВАНИЯ ----------
// В ui.html в window.onmessage нужно добавить обработку сообщения type: 'download'.
// (см. дополненный ui.html ниже)