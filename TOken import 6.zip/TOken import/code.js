// code.js — для Pixso (с поддержкой modes)
pixso.showUI(__html__, { width: 560, height: 680 });

// ================== КОНФИГ ==================
const CONFIG = {
  useColorHeuristic: false,
  primitiveCollectionPatterns: [
    /primitive/i,
    /^base/i,
    /foundation/i,
    /^core/i,
    /palette/i,
    /^colors?$/i,
    /^primitives?$/i,
    /tokens?\//i
  ]
};
// ===========================================

// ---------- Утилиты ----------

function isVariableAlias(value) {
  if (value === null || typeof value !== "object") return false;
  if (value.type === "VARIABLE_ALIAS") return true;
  if (
    typeof value.type === "string" &&
    value.type.toUpperCase() === "VARIABLE_ALIAS"
  ) return true;
  if (typeof value.id === "string" && value.id.startsWith("VariableID:")) {
    return true;
  }
  return false;
}

function isColorValue(value) {
  return (
    value !== null &&
    typeof value === "object" &&
    typeof value.r === "number" &&
    typeof value.g === "number" &&
    typeof value.b === "number"
  );
}

function rgbaToHex({ r, g, b, a = 1 }) {
  const to255 = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255);
  const hex = (n) => n.toString(16).padStart(2, "0").toUpperCase();
  const base = `#${hex(to255(r))}${hex(to255(g))}${hex(to255(b))}`;
  return a < 1 ? `${base}${hex(to255(a))}` : base;
}

async function getCollectionName(collectionId) {
  if (!collectionId) return "unknown-collection";
  try {
    const c = await pixso.variables.getVariableCollectionByIdAsync(collectionId);
    return c ? c.name : "unknown-collection";
  } catch (e) {
    return "unknown-collection";
  }
}

async function buildTokenPath(variable) {
  const collectionName = await getCollectionName(variable.variableCollectionId);
  const parts = variable.name.split("/").filter(Boolean);
  return [collectionName, ...parts].join(".");
}

async function resolveVariableById(id, localById) {
  const local = localById.get(id);
  if (local) return local;
  try {
    const remote = await pixso.variables.getVariableByIdAsync(id);
    return remote || null;
  } catch (e) {
    return null;
  }
}

/**
 * Вставка токена в итоговое дерево.
 * modeName === null  → один режим, имя не пишем.
 * modeName === "Light" и т.п. → создаём уровень режима.
 */
function insertToken(root, collectionName, variableName, value, modeName = null) {
  if (!root[collectionName]) root[collectionName] = {};

  let target = root[collectionName];

  if (modeName !== null) {
    if (!target[modeName]) target[modeName] = {};
    target = target[modeName];
  }

  const parts = variableName.split("/").filter(Boolean);
  const tokenName = parts.pop() || variableName;
  const folders = parts;

  for (const folder of folders) {
    if (!target[folder]) target[folder] = {};
    target = target[folder];
  }

  target[tokenName] = { "Value/ref": value };
}

function isPrimitiveCollection(name) {
  return CONFIG.primitiveCollectionPatterns.some((re) => re.test(name));
}

// ---------- Сбор ----------

async function collectAllTokens() {
  const result = {};
  const stats = {
    refs: 0,
    hexes: 0,
    heuristicRefs: 0,
    missingRefs: 0,
    total: 0,
    modes: 0
  };

  const collections = await pixso.variables.getLocalVariableCollectionsAsync();
  const allVariables = await pixso.variables.getLocalVariablesAsync();
  const localById = new Map(allVariables.map((v) => [v.id, v]));

  console.log("=== DIAGNOSTIC: Collections ===");
  for (const c of collections) {
    console.log(
      `"${c.name}" id=${c.id} defaultModeId=${c.defaultModeId}`,
      "modes:", JSON.stringify(c.modes)
    );
  }

  // ---- Проход 1: собрать токены и продиагностировать ----
  const allTokens = [];

  for (const collection of collections) {
    const modes = collection.modes; // Array<{ modeId, name }>
    const hasMultipleModes = modes.length > 1;
    const variables = allVariables.filter(
      (v) => v.variableCollectionId === collection.id
    );

    for (const mode of modes) {
      const modeId = mode.modeId;
      const modeName = hasMultipleModes ? mode.name : null;

      for (const variable of variables) {
        const rawValue = variable.valuesByMode[modeId];
        if (rawValue === undefined) continue;

        const aliasByType = isVariableAlias(rawValue);
        const colorByShape = isColorValue(rawValue);

        // ---- ДИАГНОСТИКА ----
        console.log(
          "[VAR]",
          JSON.stringify(
            {
              collection: collection.name,
              modeName: modeName,
              variable: variable.name,
              resolvedType: variable.resolvedType,
              rawValueStringified: JSON.stringify(rawValue),
              isAliasByType: aliasByType,
              isColorByShape: colorByShape
            },
            null,
            2
          )
        );

        allTokens.push({
          collection: collection.name,
          variable,
          modeName,
          rawValue,
          isAlias: aliasByType,
          aliasId: aliasByType ? rawValue.id : null,
          path: [
            collection.name,
            ...variable.name.split("/").filter(Boolean)
          ]
        });
      }
    }
  }

  // ---- Эвристика: карта цвет → путь примитива ----
  let hexToPrimitivePath = null;
  if (CONFIG.useColorHeuristic) {
    hexToPrimitivePath = new Map();
    for (const t of allTokens) {
      if (!isPrimitiveCollection(t.collection)) continue;
      if (t.isAlias) continue;
      if (!isColorValue(t.rawValue)) continue;
      const hex = rgbaToHex(t.rawValue);
      if (!hexToPrimitivePath.has(hex)) {
        hexToPrimitivePath.set(hex, t.path);
      }
    }
    console.log(
      "[Heuristic] primitive color map size:",
      hexToPrimitivePath.size
    );
  }

  // ---- Проход 2: сформировать итоговое дерево ----
  for (const t of allTokens) {
    let value;

    if (t.isAlias) {
      const refVar = await resolveVariableById(t.aliasId, localById);
      if (refVar) {
        const refPath = await buildTokenPath(refVar);
        value = `{${refPath}}`;
        stats.refs++;
      } else {
        value = "#missing#";
        stats.missingRefs++;
      }
    } else if (
      t.variable.resolvedType === "COLOR" &&
      isColorValue(t.rawValue)
    ) {
      const hex = rgbaToHex(t.rawValue);

      if (
        hexToPrimitivePath &&
        !isPrimitiveCollection(t.collection) &&
        hexToPrimitivePath.has(hex)
      ) {
        const primPath = hexToPrimitivePath.get(hex);
        if (primPath.join("/") !== t.path.join("/")) {
          value = `{${primPath.join(".")}}`;
          stats.heuristicRefs++;
        } else {
          value = hex;
          stats.hexes++;
        }
      } else {
        value = hex;
        stats.hexes++;
      }
    } else {
      value = t.rawValue;
    }

    if (value === null || value === undefined) continue;

    insertToken(
      result,
      t.collection,
      t.variable.name,
      value,
      t.modeName // null или имя режима
    );
    stats.total++;
    if (t.modeName !== null) stats.modes++;
  }

  console.log("[Tokens Exporter] Stats:", stats);
  return { result, stats };
}

// ---------- Сообщения ----------

pixso.ui.onmessage = async (msg) => {
  if (msg.type === "scan") {
    CONFIG.useColorHeuristic = !!msg.useHeuristic;
    try {
      const { result, stats } = await collectAllTokens();
      pixso.ui.postMessage({
        type: "scan-result",
        data: result,
        stats: {
          collections: Object.keys(result).length,
          tokens: stats.total,
          refs: stats.refs,
          hexes: stats.hexes,
          heuristicRefs: stats.heuristicRefs,
          missingRefs: stats.missingRefs,
          modes: stats.modes
        }
      });
    } catch (err) {
      console.error("[Tokens Exporter] ERROR:", err);
      pixso.ui.postMessage({
        type: "scan-error",
        message: err.message || String(err)
      });
    }
  }

  if (msg.type === "close") {
    pixso.closePlugin();
  }
};