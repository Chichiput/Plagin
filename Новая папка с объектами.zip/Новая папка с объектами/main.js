pixso.showUI(__html__, { width: 380, height: 300 });

// 1. Собираем локальные цветовые переменные и создаём карту "имя -> переменная"
async function buildLocalVariablesMap() {
  const localVars = await pixso.variables.getLocalVariablesAsync('COLOR');
  const map = new Map();
  localVars.forEach(v => map.set(v.name, v));
  return map;
}

// 2. Рекурсивно обрабатываем узел: заливки и обводки
async function reassignInNode(node, localVarsMap, stats) {
  // --- Обработка заливок (fills) ---
  if (node.fills && node.fills.length > 0) {
    const newFills = [];
    for (const paint of node.fills) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const oldAlias = paint.boundVariables.color; // VariableAlias { type, id }
        const oldVar = await pixso.variables.getVariableByIdAsync(oldAlias.id);

        if (oldVar) {
          const localVar = localVarsMap.get(oldVar.name);
          if (localVar) {
            // Переназначаем на локальную переменную с тем же именем
            const newPaint = pixso.variables.setBoundVariableForPaint(
              paint,
              'color',
              localVar
            );
            newFills.push(newPaint);
            stats.fills++;
            continue;
          }
        }
      }
      newFills.push(paint);
    }
    node.fills = newFills;
  }

  // --- Обработка обводок (strokes) ---
  if (node.strokes && node.strokes.length > 0) {
    const newStrokes = [];
    for (const paint of node.strokes) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const oldAlias = paint.boundVariables.color;
        const oldVar = await pixso.variables.getVariableByIdAsync(oldAlias.id);

        if (oldVar) {
          const localVar = localVarsMap.get(oldVar.name);
          if (localVar) {
            const newPaint = pixso.variables.setBoundVariableForPaint(
              paint,
              'color',
              localVar
            );
            newStrokes.push(newPaint);
            stats.strokes++;
            continue;
          }
        }
      }
      newStrokes.push(paint);
    }
    node.strokes = newStrokes;
  }

  // Рекурсия по дочерним элементам
  if ('children' in node) {
    for (const child of node.children) {
      await reassignInNode(child, localVarsMap, stats);
    }
  }
}

// 3. Запуск переназначения по всему файлу
async function reassignAll() {
  const localVarsMap = await buildLocalVariablesMap();
  if (localVarsMap.size === 0) {
    return { error: 'В файле не найдено локальных цветовых переменных.' };
  }

  const stats = { fills: 0, strokes: 0 };
  const pages = pixso.root.children; // все страницы файла

  for (const page of pages) {
    const components = await page.findAllAsync(
      n => n.type === 'COMPONENT' || n.type === 'COMPONENT_SET'
    );

    for (const comp of components) {
      if (comp.type === 'COMPONENT_SET') {
        for (const variant of comp.children) {
          if (variant.type === 'COMPONENT') {
            await reassignInNode(variant, localVarsMap, stats);
          }
        }
      } else {
        await reassignInNode(comp, localVarsMap, stats);
      }
    }
  }

  return stats;
}

// 4. Обработка сообщений от UI
pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'start') {
    try {
      const result = await reassignAll();
      pixso.ui.postMessage({ type: 'done', result });
    } catch (e) {
      pixso.ui.postMessage({ type: 'error', message: e.message });
    }
  }
};