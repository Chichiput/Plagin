// code.js

pixso.showUI(__html__, { width: 420, height: 580, title: "Font Scanner" });

// Собираем шрифты только из текстовых стилей:
// локальных и подключённых через библиотеку.
function getFontsFromStyles() {
  const fonts = [];

  // 1. Локальные текстовые стили
  try {
    const localStyles = pixso.getLocalTextStyles();
    for (const style of localStyles) {
      if (style.fontName && style.fontName !== pixso.mixed) {
        fonts.push(style.fontName);
      }
    }
  } catch (e) {
    console.error("Ошибка при получении локальных стилей:", e);
  }

  // 2. Текстовые стили из подключённых библиотек
  try {
    const libraryStyles = pixso.getLibraryStylesInUse();
    for (const style of libraryStyles) {
      if (
        style.type === "TEXT" &&
        style.fontName &&
        style.fontName !== pixso.mixed
      ) {
        fonts.push(style.fontName);
      }
    }
  } catch (e) {
    console.error("Ошибка при получении стилей библиотек:", e);
  }

  // Дедупликация по паре family + style
  const uniqueMap = new Map();
  for (const font of fonts) {
    const key = `${font.family}::${font.style}`;
    if (!uniqueMap.has(key)) {
      uniqueMap.set(key, font);
    }
  }

  return Array.from(uniqueMap.values());
}

// Отправляем список шрифтов в UI при запуске
(function () {
  const fonts = getFontsFromStyles();
  pixso.ui.postMessage({ type: "fonts-loaded", fonts });
})();

pixso.ui.onmessage = async (msg) => {
  if (msg.type === "scan") {
    await scanFileForFont(msg.font);
  } else if (msg.type === "focus") {
    const node = await pixso.getNodeByIdAsync(msg.id);
    if (node) {
      pixso.viewport.scrollAndZoomIntoView([node]);
      pixso.currentPage.selection = [node];
    }
  }
};

async function scanFileForFont(targetFont) {
  const allComponents = [];
  collectComponents(pixso.root, allComponents);

  const total = allComponents.length;
  const found = [];

  if (total === 0) {
    pixso.ui.postMessage({ type: "result", components: [] });
    return;
  }

  for (let i = 0; i < allComponents.length; i++) {
    const comp = allComponents[i];

    pixso.ui.postMessage({
      type: "progress",
      current: i + 1,
      total: total,
      componentName: comp.name || "(без имени)",
    });

    if (componentUsesFont(comp, targetFont)) {
      found.push({ id: comp.id, name: comp.name || "(без имени)" });
    }

    // Даём UI передохнуть, чтобы прогресс-бар плавно обновлялся
    if (i % 5 === 0) {
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  pixso.ui.postMessage({ type: "result", components: found });
}

function collectComponents(node, list) {
  if (node.type === "COMPONENT" || node.type === "COMPONENT_SET") {
    list.push(node);
  }
  if ("children" in node) {
    for (const child of node.children) {
      collectComponents(child, list);
    }
  }
}

function componentUsesFont(node, targetFont) {
  if (node.type === "TEXT") {
    // 1. Основной критерий — стиль текста (в т.ч. библиотечный)
    if (node.textStyleId) {
      try {
        const style = pixso.getStyleById(node.textStyleId);
        if (
          style &&
          style.type === "TEXT" &&
          style.fontName &&
          style.fontName !== pixso.mixed &&
          fontEquals(style.fontName, targetFont)
        ) {
          return true;
        }
      } catch (e) {
        // стиль мог быть удалён из библиотеки — игнорируем
      }
    }

    // 2. Дополнительно — прямое назначение шрифта
    if (checkFontName(node.fontName, node, targetFont)) {
      return true;
    }
  }

  if ("children" in node) {
    for (const child of node.children) {
      if (componentUsesFont(child, targetFont)) return true;
    }
  }

  return false;
}

function checkFontName(fontName, textNode, targetFont) {
  if (fontName === pixso.mixed) {
    for (let i = 0; i < textNode.characters.length; i++) {
      const rangeFont = textNode.getRangeFontName(i, i + 1);
      if (rangeFont !== pixso.mixed && fontEquals(rangeFont, targetFont)) {
        return true;
      }
    }
    return false;
  }
  return fontEquals(fontName, targetFont);
}

function fontEquals(a, b) {
  return a.family === b.family && a.style === b.style;
}