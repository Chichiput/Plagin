// code.js

pixso.showUI(__html__, { width: 420, height: 580, title: "Font Scanner" });

// Загружаем список доступных шрифтов и отправляем в UI
(async () => {
  const fonts = await pixso.listAvailableFontsAsync();
  pixso.ui.postMessage({ type: "fonts-loaded", fonts });
})();

pixso.ui.onmessage = async (msg) => {
  if (msg.type === "scan") {
    await scanFileForFont(msg.font);
  } else if (msg.type === "focus") {
    const node = await pixso.getNodeByIdAsync(msg.id);
    if (node) {
      pixso.viewport.scrollAndZoomIntoView([node]);
      pixso.currentPage.selection = [node];
    }
  }
};

async function scanFileForFont(targetFont) {
  const allComponents = [];
  collectComponents(pixso.root, allComponents);

  const total = allComponents.length;
  const found = [];

  for (let i = 0; i < allComponents.length; i++) {
    const comp = allComponents[i];

    pixso.ui.postMessage({
      type: "progress",
      current: i + 1,
      total: total,
      componentName: comp.name,
    });

    if (componentUsesFont(comp, targetFont)) {
      found.push({ id: comp.id, name: comp.name });
    }

    if (i % 5 === 0) await new Promise((r) => setTimeout(r, 0));
  }

  pixso.ui.postMessage({ type: "result", components: found });
}

function collectComponents(node, list) {
  if (node.type === "COMPONENT" || node.type === "COMPONENT_SET") {
    list.push(node);
  }
  if ("children" in node) {
    for (const child of node.children) {
      collectComponents(child, list);
    }
  }
}

function componentUsesFont(node, targetFont) {
  if (node.type === "TEXT") {
    const fontName = node.fontName;

    if (fontName === pixso.mixed) {
      for (let i = 0; i < node.characters.length; i++) {
        const rangeFont = node.getRangeFontName(i, i + 1);
        if (rangeFont !== pixso.mixed && fontEquals(rangeFont, targetFont)) {
          return true;
        }
      }
      return false;
    }

    return fontEquals(fontName, targetFont);
  }

  if ("children" in node) {
    for (const child of node.children) {
      if (componentUsesFont(child, targetFont)) return true;
    }
  }

  return false;
}

function fontEquals(a, b) {
  return a.family === b.family && a.style === b.style;
}