// code.js — для Pixso
pixso.showUI(__html__, { width: 560, height: 680 });

// ================== КОНФИГ ==================
const CONFIG = {
  // Если Pixso корректно возвращает алиасы — оставьте false.
  // Если у токенов-ссылок приходит уже RGB (видите HEX вместо ссылки) —
  // включите галочку в интерфейсе или поставьте true здесь.
  useColorHeuristic: false,

  // Коллекции, которые считаются «примитивами» (источниками).
  // Токены из них НИКОГДА не превращаются в ссылки через эвристику.
  primitiveCollectionPatterns: [
    /primitive/i,
    /^base/i,
    /foundation/i,
    /^core/i,
    /palette/i,
    /^colors?$/i,
    /^primitives?$/i,
    /tokens?\//i
  ]
};
// ===========================================

// ---------- Утилиты ----------

function isVariableAlias(value) {
  if (value === null || typeof value !== "object") return false;
  if (value.type === "VARIABLE_ALIAS") return true;
  if (
    typeof value.type === "string" &&
    value.type.toUpperCase() === "VARIABLE_ALIAS"
  ) return true;
  if (typeof value.id === "string" && value.id.startsWith("VariableID:")) {
    return true;
  }
  return false;
}

function isColorValue(value) {
  return (
    value !== null &&
    typeof value === "object" &&
    typeof value.r === "number" &&
    typeof value.g === "number" &&
    typeof value.b === "number"
  );
}

function rgbaToHex({ r, g, b, a = 1 }) {
  const to255 = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255);
  const hex = (n) => n.toString(16).padStart(2, "0").toUpperCase();
  const base = `#${hex(to255(r))}${hex(to255(g))}${hex(to255(b))}`;
  return a < 1 ? `${base}${hex(to255(a))}` : base;
}

async function getCollectionName(collectionId) {
  if (!collectionId) return "unknown-collection";
  try {
    const c = await pixso.variables.getVariableCollectionByIdAsync(collectionId);
    return c ? c.name : "unknown-collection";
  } catch (e) {
    return "unknown-collection";
  }
}

async function buildTokenPath(variable) {
  const collectionName = await getCollectionName(variable.variableCollectionId);
  const parts = variable.name.split("/").filter(Boolean);
  return [collectionName, ...parts].join(".");
}

async function resolveVariableById(id, localById) {
  const local = localById.get(id);
  if (local) return local;
  try {
    const remote = await pixso.variables.getVariableByIdAsync(id);
    return remote || null;
  } catch (e) {
    return null;
  }
}

function insertToken(root, collectionName, variableName, value) {
  const parts = variableName.split("/").filter(Boolean);
  const tokenName = parts.pop() || variableName;
  const folders = parts;

  if (!root[collectionName]) root[collectionName] = {};
  let current = root[collectionName];
  for (const folder of folders) {
    if (!current[folder]) current[folder] = {};
    current = current[folder];
  }
  current[tokenName] = { "Value/ref": value };
}

function isPrimitiveCollection(name) {
  return CONFIG.primitiveCollectionPatterns.some((re) => re.test(name));
}

// ---------- Сбор ----------

async function collectAllTokens() {
  const result = {};
  const stats = {
    refs: 0,          // настоящих алиасов (type=VARIABLE_ALIAS)
    hexes: 0,         // чистых цветов
    heuristicRefs: 0, // ссылок, найденных эвристикой
    missingRefs: 0,   // алиасов, которые не удалось разрешить
    total: 0
  };

  const collections = await pixso.variables.getLocalVariableCollectionsAsync();
  const allVariables = await pixso.variables.getLocalVariablesAsync();
  const localById = new Map(allVariables.map((v) => [v.id, v]));

  console.log("=== DIAGNOSTIC: Collections ===");
  for (const c of collections) {
    console.log(
      `"${c.name}" id=${c.id} defaultModeId=${c.defaultModeId}`,
      "modes:", JSON.stringify(c.modes)
    );
  }

  // ---- Проход 1: собрать все токены и продиагностировать ----
  const allTokens = [];

  for (const collection of collections) {
    const modeId = collection.defaultModeId;
    const variables = allVariables.filter(
      (v) => v.variableCollectionId === collection.id
    );

    for (const variable of variables) {
      const rawValue = variable.valuesByMode[modeId];
      const aliasByType = isVariableAlias(rawValue);
      const colorByShape = isColorValue(rawValue);

      // ---- ДИАГНОСТИКА ----
      const dump = {
        collection: collection.name,
        name: variable.name,
        resolvedType: variable.resolvedType,
        modeIdUsed: modeId,
        valuesByModeKeys: Object.keys(variable.valuesByMode),
        rawValueStringified: JSON.stringify(rawValue),
        isAliasByType: aliasByType,
        isColorByShape: colorByShape
      };
      console.log("[VAR]", JSON.stringify(dump, null, 2));

      // Дамп всех собственных свойств — вдруг Pixso прячет алиас
      // в другом поле (rawValue/sourceValue/originalValue/aliasOf и т.п.)
      const ownProps = Object.getOwnPropertyNames(variable);
      const interestingProps = ownProps.filter((p) => {
        const v = variable[p];
        return typeof v !== "function" && p !== "valuesByMode";
      });
      for (const p of interestingProps) {
        try {
          const v = variable[p];
          const str =
            v !== null && typeof v === "object"
              ? JSON.stringify(v)
              : String(v);
          if (str && str.length > 200) {
            console.log(`  .${p} = ${str.slice(0, 200)}...`);
          } else if (str !== "undefined") {
            console.log(`  .${p} = ${str}`);
          }
        } catch (e) {
          console.log(`  .${p} = [error: ${e.message}]`);
        }
      }

      allTokens.push({
        collection: collection.name,
        variable,
        rawValue,
        isAlias: aliasByType,
        aliasId: aliasByType ? rawValue.id : null,
        path: [
          collection.name,
          ...variable.name.split("/").filter(Boolean)
        ]
      });
    }
  }

  // ---- Эвристика: построить карту цвет→путь примитивов ----
  let hexToPrimitivePath = null;
  if (CONFIG.useColorHeuristic) {
    hexToPrimitivePath = new Map();
    for (const t of allTokens) {
      if (!isPrimitiveCollection(t.collection)) continue;
      if (t.isAlias) continue;
      if (!isColorValue(t.rawValue)) continue;
      const hex = rgbaToHex(t.rawValue);
      if (!hexToPrimitivePath.has(hex)) {
        hexToPrimitivePath.set(hex, t.path);
      }
    }
    console.log(
      "[Heuristic] primitive color map size:",
      hexToPrimitivePath.size
    );
  }

  // ---- Проход 2: сформировать итоговое дерево ----
  for (const t of allTokens) {
    let value;

    if (t.isAlias) {
      // Настоящий алиас по API
      const refVar = await resolveVariableById(t.aliasId, localById);
      if (refVar) {
        const refPath = await buildTokenPath(refVar);
        value = `{${refPath}}`;
        stats.refs++;
      } else {
        value = "#missing#";
        stats.missingRefs++;
      }
    } else if (
      t.variable.resolvedType === "COLOR" &&
      isColorValue(t.rawValue)
    ) {
      const hex = rgbaToHex(t.rawValue);

      // Пробуем эвристику
      if (
        hexToPrimitivePath &&
        !isPrimitiveCollection(t.collection) &&
        hexToPrimitivePath.has(hex)
      ) {
        const primPath = hexToPrimitivePath.get(hex);
        if (primPath.join("/") !== t.path.join("/")) {
          value = `{${primPath.join(".")}}`;
          stats.heuristicRefs++;
        } else {
          value = hex;
          stats.hexes++;
        }
      } else {
        value = hex;
        stats.hexes++;
      }
    } else {
      value = t.rawValue;
    }

    if (value === null || value === undefined) continue;
    insertToken(result, t.collection, t.variable.name, value);
    stats.total++;
  }

  console.log("[Tokens Exporter] Stats:", stats);
  return { result, stats };
}

// ---------- Сообщения ----------

pixso.ui.onmessage = async (msg) => {
  if (msg.type === "scan") {
    CONFIG.useColorHeuristic = !!msg.useHeuristic;
    try {
      const { result, stats } = await collectAllTokens();
      pixso.ui.postMessage({
        type: "scan-result",
        data: result,
        stats: {
          collections: Object.keys(result).length,
          tokens: stats.total,
          refs: stats.refs,
          hexes: stats.hexes,
          heuristicRefs: stats.heuristicRefs,
          missingRefs: stats.missingRefs
        }
      });
    } catch (err) {
      console.error("[Tokens Exporter] ERROR:", err);
      pixso.ui.postMessage({
        type: "scan-error",
        message: err.message || String(err)
      });
    }
  }

  if (msg.type === "close") {
    pixso.closePlugin();
  }
};