// code.js
// Открываем UI сразу при запуске плагина
pixso.showUI(__html__, { width: 420, height: 360 });

pixso.ui.onmessage = async (msg) => {
  // Кнопка "Запустить" в UI -> запрос на анализ коллекций
  if (msg.type === 'start-analysis') {
    await analyzeCollections();
  }

  // Кнопка "Скачать JSON" -> экспорт всех коллекций
  if (msg.type === 'download-json') {
    await downloadAllCollections(msg.format);
  }
};

async function analyzeCollections() {
  try {
    const collections = await pixso.variables.getLocalVariableCollectionsAsync();
    // Отправляем в UI количество найденных коллекций
    pixso.ui.postMessage({
      type: 'analysis-result',
      count: collections.length,
      names: collections.map(c => c.name)
    });
  } catch (err) {
    pixso.ui.postMessage({ type: 'error', message: err.message });
  }
}

async function downloadAllCollections(format) {
  try {
    const collections = await pixso.variables.getLocalVariableCollectionsAsync();
    if (collections.length === 0) {
      pixso.ui.postMessage({ type: 'error', message: 'Нет локальных коллекций переменных.' });
      return;
    }

    for (const collection of collections) {
      const tokensJson = await buildCollectionTokens(collection, format);
      const safeName = collection.name.replace(/[^a-z0-9а-яё\-_]/gi, '_');
      const fileName = `${safeName}.tokens.json`;

      // Отправляем каждый файл в UI для скачивания
      pixso.ui.postMessage({
        type: 'download-file',
        fileName,
        content: JSON.stringify(tokensJson, null, 2)
      });
    }

    // Сообщаем UI, что все файлы отправлены
    pixso.ui.postMessage({ type: 'download-complete', total: collections.length });
  } catch (err) {
    pixso.ui.postMessage({ type: 'error', message: err.message });
  }
}

// ===== Вспомогательные функции (те же, что и раньше) =====
async function buildCollectionTokens(collection, format) {
  const variables = await Promise.all(
    collection.variableIds.map(id => pixso.variables.getVariableByIdAsync(id))
  );
  const root = {};
  for (const variable of variables) {
    if (!variable) continue;
    const token = buildTokenValue(variable, collection, format);
    setNestedToken(root, variable.name, token);
  }
  return root;
}

function buildTokenValue(variable, collection, format) {
  const type = variable.resolvedType;
  const valuesByMode = {};
  for (const mode of collection.modes) {
    const rawValue = variable.valuesByMode[mode.modeId];
    valuesByMode[mode.name] = rawValue;
  }
  if (format === 'DTCG') {
    return {
      $type: mapTypeToDTCG(type),
      $value: valuesByMode[collection.modes[0].name],
      $extensions: { modes: valuesByMode }
    };
  }
  return {
    value: valuesByMode[collection.modes[0].name],
    type: mapTypeToLegacy(type),
    modes: valuesByMode
  };
}

function mapTypeToDTCG(pixsoType) {
  const map = { COLOR: 'color', FLOAT: 'dimension', STRING: 'string', BOOLEAN: 'boolean' };
  return map[pixsoType] || 'string';
}

function mapTypeToLegacy(pixsoType) {
  const map = { COLOR: 'color', FLOAT: 'spacing', STRING: 'text', BOOLEAN: 'boolean' };
  return map[pixsoType] || 'other';
}

function setNestedToken(root, path, token) {
  const parts = path.split('.');
  let current = root;
  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i];
    if (!current[part] || typeof current[part] !== 'object') current[part] = {};
    current = current[part];
  }
  current[parts[parts.length - 1]] = token;
}