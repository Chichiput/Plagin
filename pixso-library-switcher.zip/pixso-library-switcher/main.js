const requiredNames = [
  '[W] LIB-DSN 01 Components DCB Next v.1.50.0',
  '[W] LIB-DSN 02 Components DCB Next v.1.50.0',
  '[M] LIB-DSN 01 Components DCB Next v.4.05.0',
  '[M] LIB-DSN 02 Components DCB Next v.4.05.0',
  '[W] LIB-DSN 03 Components DCB Next v.1.50.0',
  '[W] LIB-DSN+ Product Components Next v.1.50.0',
  '[M] LIB-DSN+ Product components Next v.4.05.0',
  '[S] LIB-COR Styles Infographics DCB Next v.1.1.0',
  '[S] LIB-DSN Infographics DCB Next v.1.2.0',
  'LIB-DSN Icons DCB Next v.1.48.0',
  'LIB-DSN Skeletons DCB Next v.1.1.0',
  'LIB-COR Styles Next v.1.1.0',
];

function matches(name, requiredName) {
  return name.trim() === requiredName ||
    (requiredName === requiredNames[0] && name.trim() === requiredName.slice(1));
}

async function readPlan() {
  if (typeof pixso.getLibraryListAsync !== 'function' ||
      typeof pixso.subscribeLibraryAsync !== 'function' ||
      typeof pixso.unsubscribeLibraryAsync !== 'function') {
    throw new Error('В этой версии Pixso недоступно управление подписками через API плагинов.');
  }
  const result = await pixso.getLibraryListAsync();
  const libraries = Array.isArray(result) ? result : [result];
  const byKey = new Map();
  for (const library of libraries) {
    if (!library || typeof library.name !== 'string' ||
        typeof library.key !== 'string' || !library.key ||
        typeof library.subscribed !== 'boolean') {
      throw new Error('Pixso вернул список библиотек в неизвестном формате.');
    }
    const previous = byKey.get(library.key);
    if (previous && (previous.name !== library.name || previous.subscribed !== library.subscribed)) {
      throw new Error('Pixso вернул противоречивые данные для библиотеки «' + library.name + '».');
    }
    byKey.set(library.key, library);
  }

  const targets = [];
  const issues = [];
  for (const name of requiredNames) {
    const candidates = Array.from(byKey.values()).filter(library => matches(library.name, name));
    if (candidates.length === 1) {
      targets.push(candidates[0]);
    } else if (candidates.length === 0) {
      issues.push('Не найдена: ' + name);
    } else {
      const teams = candidates.map(library => library.teamName || library.key);
      issues.push('Несколько совпадений: ' + name + ' (' + teams.join(', ') + ')');
    }
  }

  const targetKeys = new Set(targets.map(library => library.key));
  return {
    issues,
    targets,
    enable: targets.filter(library => !library.subscribed),
    disable: Array.from(byKey.values()).filter(library => library.subscribed && !targetKeys.has(library.key)),
  };
}

function planSignature(plan) {
  return JSON.stringify([plan.targets, plan.enable, plan.disable].map(
    libraries => libraries.map(library => library.key).sort()
  ));
}

function send(type, data) {
  pixso.ui.postMessage(Object.assign({ type }, data));
}

let preview;
let busy = false;

function showPlan(plan, message) {
  preview = plan;
  const label = library => library.teamName ? library.name + ' · ' + library.teamName : library.name;
  send('plan', {
    found: plan.targets.length,
    total: requiredNames.length,
    issues: plan.issues,
    enable: plan.enable.map(label),
    disable: plan.issues.length ? [] : plan.disable.map(label),
    message,
  });
}

async function applyPlan(plan) {
  const total = plan.enable.length + plan.disable.length;
  let completed = 0;
  async function change(library, enable) {
    const action = enable ? 'Подключение' : 'Отключение';
    send('progress', { completed, total, message: action + ' · ' + library.name });
    try {
      if (enable) {
        await pixso.subscribeLibraryAsync(library.key);
      } else {
        await pixso.unsubscribeLibraryAsync(library.key);
      }
    } catch (error) {
      throw new Error(action + ' «' + library.name + '»: ' + (error.message || String(error)));
    }
    completed += 1;
  }

  for (const library of plan.enable) {
    await change(library, true);
  }
  const beforeDisable = await readPlan();
  if (beforeDisable.issues.length || beforeDisable.enable.length ||
      planSignature(beforeDisable) !== planSignature({ ...plan, enable: [] })) {
    showPlan(beforeDisable, 'Список или состояние библиотек изменились. Проверьте новый план.');
    return;
  }
  for (const library of plan.disable) {
    await change(library, false);
  }

  send('progress', { completed, total, message: 'Проверяем подписки…' });
  const result = await readPlan();
  const success = !result.issues.length && !result.enable.length && !result.disable.length;
  showPlan(result, success
    ? 'Готово. Подключено: ' + plan.enable.length + '. Отключено: ' + plan.disable.length + '.'
    : 'Pixso пока не подтвердил все изменения. Проверьте текущий список.');
}

pixso.ui.onmessage = async message => {
  if (!message || busy || (message.type !== 'load' && message.type !== 'apply')) return;
  busy = true;
  const previous = preview;
  preview = undefined;
  try {
    const plan = await readPlan();
    if (message.type === 'load' || !previous || previous.issues.length) {
      showPlan(plan);
    } else if (plan.issues.length || planSignature(plan) !== planSignature(previous)) {
      showPlan(plan, 'Список или состояние библиотек изменились. Проверьте новый план.');
    } else if (plan.enable.length || plan.disable.length) {
      await applyPlan(plan);
    } else {
      showPlan(plan);
    }
  } catch (error) {
    send('error', { message: error.message || String(error) });
  } finally {
    busy = false;
  }
};

pixso.showUI(__html__, { width: 450, height: 510 });
