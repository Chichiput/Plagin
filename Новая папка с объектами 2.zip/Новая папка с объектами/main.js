pixso.showUI(__html__, { width: 380, height: 320 });

let isRunning = false;

// 1. Собираем локальные цветовые переменные: имя -> переменная
async function buildLocalVariablesMap() {
  const localVars = await pixso.variables.getLocalVariablesAsync('COLOR');
  const map = new Map();
  localVars.forEach(v => map.set(v.name, v));
  return map;
}

// 2. Рекурсивно обрабатываем узел: заливки и обводки
async function reassignInNode(node, localVarsMap, stats) {
  // --- Заливки ---
  if (node.fills && node.fills.length > 0) {
    const newFills = [];
    for (const paint of node.fills) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const oldAlias = paint.boundVariables.color;
        const oldVar = await pixso.variables.getVariableByIdAsync(oldAlias.id);

        if (oldVar) {
          const localVar = localVarsMap.get(oldVar.name);
          if (localVar && localVar.id !== oldAlias.id) {
            const newPaint = pixso.variables.setBoundVariableForPaint(
              paint,
              'color',
              localVar
            );
            newFills.push(newPaint);
            stats.fills++;
            continue;
          }
        }
      }
      newFills.push(paint);
    }
    node.fills = newFills;
  }

  // --- Обводки ---
  if (node.strokes && node.strokes.length > 0) {
    const newStrokes = [];
    for (const paint of node.strokes) {
      if (paint.type === 'SOLID' && paint.boundVariables?.color) {
        const oldAlias = paint.boundVariables.color;
        const oldVar = await pixso.variables.getVariableByIdAsync(oldAlias.id);

        if (oldVar) {
          const localVar = localVarsMap.get(oldVar.name);
          if (localVar && localVar.id !== oldAlias.id) {
            const newPaint = pixso.variables.setBoundVariableForPaint(
              paint,
              'color',
              localVar
            );
            newStrokes.push(newPaint);
            stats.strokes++;
            continue;
          }
        }
      }
      newStrokes.push(paint);
    }
    node.strokes = newStrokes;
  }

  // Рекурсия по дочерним узлам
  if ('children' in node) {
    for (const child of node.children) {
      await reassignInNode(child, localVarsMap, stats);
    }
  }
}

// 3. Запуск переназначения — ТОЛЬКО на текущей странице
async function reassignCurrentPage() {
  const localVarsMap = await buildLocalVariablesMap();
  if (localVarsMap.size === 0) {
    return { error: 'В файле не найдено локальных цветовых переменных.' };
  }

  const page = pixso.currentPage;
  if (!page) {
    return { error: 'Не удалось получить текущую страницу.' };
  }

  const stats = {
    fills: 0,
    strokes: 0,
    components: 0,
    pageName: page.name
  };

  // Находим все компоненты и наборы компонентов на текущей странице
  const components = await page.findAllAsync(
    n => n.type === 'COMPONENT' || n.type === 'COMPONENT_SET'
  );

  if (components.length === 0) {
    return {
      error: `На странице «${page.name}» не найдено компонентов.`,
      pageName: page.name
    };
  }

  for (const comp of components) {
    if (comp.type === 'COMPONENT_SET') {
      for (const variant of comp.children) {
        if (variant.type === 'COMPONENT') {
          await reassignInNode(variant, localVarsMap, stats);
          stats.components++;
        }
      }
    } else {
      await reassignInNode(comp, localVarsMap, stats);
      stats.components++;
    }
  }

  return stats;
}

// 4. Обработка сообщений от UI
pixso.ui.onmessage = async (msg) => {
  if (msg.type === 'start') {
    if (isRunning) {
      pixso.ui.postMessage({
        type: 'error',
        message: 'Обработка уже идёт, дождитесь завершения.'
      });
      return;
    }

    isRunning = true;
    try {
      const result = await reassignCurrentPage();
      pixso.ui.postMessage({ type: 'done', result });
    } catch (e) {
      pixso.ui.postMessage({ type: 'error', message: e.message });
    } finally {
      isRunning = false;
    }
  }
};